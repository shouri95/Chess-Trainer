// Mobile surfaces for Pattern Coach. Same design language, restructured for
// a single-column phone canvas with a bottom tab bar instead of a side rail.

const {
  PC_COLORS: MX,
  Board: MXBoard,
  EvalBar: MXEval,
  MoveMap: MXMoveMap,
  Pill: MXPill,
  Btn: MXBtn,
} = window;

const PHONE_W = 393;
const PHONE_H = 852;

// ───────────────────────────────────────────────────────────────
// Shared mobile chrome
// ───────────────────────────────────────────────────────────────

function PhoneScreen({ children, scroll = true, padBottom = 110 }) {
  return (
    <div style={{
      width: PHONE_W, height: PHONE_H,
      background: MX.bg,
      color: MX.text,
      fontFamily: '"Hanken Grotesk", system-ui, sans-serif',
      display: 'flex', flexDirection: 'column',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        flex: 1,
        overflow: scroll ? 'auto' : 'hidden',
        paddingTop: 56, paddingBottom: padBottom,
      }}>
        {children}
      </div>
    </div>
  );
}

function StatusOverlay({ time = '9:41' }) {
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0,
      height: 54, padding: '16px 24px 0',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      zIndex: 5,
      pointerEvents: 'none',
    }}>
      <div style={{
        fontSize: 15.5, fontWeight: 600, letterSpacing: '-0.01em',
        color: MX.text,
        fontFamily: 'SF Pro, -apple-system, system-ui',
      }}>{time}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="17" height="11" viewBox="0 0 17 11"><g fill={MX.text}>
          <rect x="0" y="6" width="3" height="5" rx="0.5"/>
          <rect x="5" y="3" width="3" height="8" rx="0.5"/>
          <rect x="10" y="0" width="3" height="11" rx="0.5"/>
        </g></svg>
        <svg width="16" height="11" viewBox="0 0 16 11" fill="none">
          <path d="M8 9.5 Q 8 6 12 5.5 M8 9.5 Q 8 4 14 3 M8 9.5 Q 8 2 16 0.5" stroke={MX.text} strokeWidth="1.2" fill="none"/>
        </svg>
        <div style={{
          width: 24, height: 11, borderRadius: 2,
          border: '1px solid ' + MX.text,
          position: 'relative', padding: 1.5,
        }}>
          <div style={{ width: '78%', height: '100%', background: MX.text, borderRadius: 1 }} />
        </div>
      </div>
    </div>
  );
}

function HomeIndicator({ light = true }) {
  return (
    <div style={{
      position: 'absolute', bottom: 8, left: 0, right: 0,
      display: 'flex', justifyContent: 'center', zIndex: 60,
    }}>
      <div style={{
        width: 134, height: 5, borderRadius: 3,
        background: light ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.4)',
      }} />
    </div>
  );
}

function TabBar({ active }) {
  const tabs = [
    { id: 'dashboard', label: 'Home',  icon: HomeIcon },
    { id: 'games',     label: 'Games', icon: GamesIcon },
    { id: 'lab',       label: 'Lab',   icon: LabIcon },
    { id: 'drill',     label: 'Drill', icon: DrillIcon },
    { id: 'profile',   label: 'Me',    icon: MeIcon },
  ];
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0,
      paddingBottom: 28, paddingTop: 10,
      background: 'linear-gradient(180deg, rgba(12,12,13,0) 0%, rgba(12,12,13,0.85) 35%, rgba(12,12,13,1) 100%)',
      zIndex: 40,
    }}>
      <div style={{
        margin: '0 16px',
        padding: '10px 8px',
        borderRadius: 24,
        background: 'rgba(28,28,31,0.92)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255,255,255,0.05)',
        boxShadow: '0 12px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)',
        display: 'flex', justifyContent: 'space-around',
      }}>
        {tabs.map(t => {
          const isActive = t.id === active;
          const Icon = t.icon;
          return (
            <div key={t.id} style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              gap: 4, padding: '4px 10px',
              opacity: isActive ? 1 : 0.5,
            }}>
              <Icon active={isActive} />
              <div style={{
                fontSize: 10, color: isActive ? MX.text : MX.textMute,
                letterSpacing: '0.02em',
                fontWeight: isActive ? 500 : 400,
              }}>{t.label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Custom tiny iconography — geometric, matches the calm tool tone.
const ICON = { size: 20, stroke: 1.4 };
function HomeIcon({ active }) {
  return (
    <svg width={ICON.size} height={ICON.size} viewBox="0 0 20 20" fill="none">
      <circle cx="10" cy="10" r="6" stroke={MX.text} strokeWidth={ICON.stroke} />
      <circle cx="10" cy="10" r="2" fill={active ? MX.you : 'none'} stroke={active ? 'none' : MX.text} strokeWidth={ICON.stroke} />
    </svg>
  );
}
function GamesIcon() {
  return (
    <svg width={ICON.size} height={ICON.size} viewBox="0 0 20 20" fill="none">
      <rect x="3" y="3" width="6" height="6" stroke={MX.text} strokeWidth={ICON.stroke} />
      <rect x="11" y="3" width="6" height="6" stroke={MX.text} strokeWidth={ICON.stroke} />
      <rect x="3" y="11" width="6" height="6" stroke={MX.text} strokeWidth={ICON.stroke} />
      <rect x="11" y="11" width="6" height="6" stroke={MX.text} strokeWidth={ICON.stroke} />
    </svg>
  );
}
function LabIcon() {
  return (
    <svg width={ICON.size} height={ICON.size} viewBox="0 0 20 20" fill="none">
      <path d="M10 3 L17 10 L10 17 L3 10 Z" stroke={MX.text} strokeWidth={ICON.stroke} />
    </svg>
  );
}
function DrillIcon() {
  return (
    <svg width={ICON.size} height={ICON.size} viewBox="0 0 20 20" fill="none">
      <path d="M4 4 L16 4 L10 16 Z" stroke={MX.text} strokeWidth={ICON.stroke} />
    </svg>
  );
}
function MeIcon() {
  return (
    <svg width={ICON.size} height={ICON.size} viewBox="0 0 20 20" fill="none">
      <circle cx="10" cy="7" r="3" stroke={MX.text} strokeWidth={ICON.stroke} />
      <path d="M3 18 Q 10 12 17 18" stroke={MX.text} strokeWidth={ICON.stroke} fill="none" />
    </svg>
  );
}

function PageHead({ eyebrow, title, right }) {
  return (
    <div style={{ padding: '4px 24px 18px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
      <div>
        {eyebrow && (
          <div style={{
            fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
            color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
            marginBottom: 6,
          }}>{eyebrow}</div>
        )}
        <h1 style={{
          margin: 0, fontSize: 30, fontWeight: 400,
          letterSpacing: '-0.028em', color: MX.text, lineHeight: 1,
        }}>{title}</h1>
      </div>
      {right}
    </div>
  );
}

function CircleBtn({ children, size = 36 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      border: '1px solid ' + MX.line,
      background: MX.surface,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: MX.textMute, fontSize: 13,
    }}>{children}</div>
  );
}

// ───────────────────────────────────────────────────────────────
// Mobile: Dashboard
// ───────────────────────────────────────────────────────────────

function MobileDashboard() {
  return (
    <PhoneScreen>
      <PageHead
        eyebrow="Tue · May 20"
        title={<>Hi, <span style={{ fontFamily: '"Instrument Serif", serif', fontStyle: 'italic' }}>Ola</span></>}
        right={<CircleBtn>↗</CircleBtn>}
      />

      {/* Hero weakness card */}
      <div style={{ margin: '0 16px 18px', position: 'relative' }}>
        <div style={{
          padding: '22px 22px 24px',
          borderRadius: 22,
          background: 'radial-gradient(ellipse at 30% 0%, #1d1a14 0%, #131311 60%, #0e0e0d 100%)',
          border: '1px solid ' + MX.line,
          overflow: 'hidden',
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <MXPill tone="you">Main weakness</MXPill>
            <span style={{
              fontSize: 10, color: MX.textMute,
              fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.08em',
              display: 'flex', alignItems: 'center', gap: 5,
            }}>
              <span style={{ width: 5, height: 5, borderRadius: '50%', background: MX.neutral }} />
              STABLE
            </span>
          </div>

          <MobileReplyOrbit />

          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
            paddingTop: 18, marginTop: 4, borderTop: '1px solid ' + MX.line,
          }}>
            <MMetric label="Spots" value="14" />
            <MMetric label="Review" value="4" unit="min" divider />
            <MMetric label="Clean" value="33" unit="%" divider />
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
            <button style={{
              flex: 1, padding: '13px 14px',
              borderRadius: 10, border: 'none',
              background: MX.text, color: '#0c0c0d',
              fontFamily: 'inherit', fontSize: 14, fontWeight: 500,
              letterSpacing: '-0.005em',
            }}>Train · 4m</button>
            <button style={{
              padding: '13px 14px',
              borderRadius: 10,
              border: '1px solid ' + MX.line, background: 'transparent',
              color: MX.text, fontFamily: 'inherit', fontSize: 14,
            }}>Review</button>
          </div>
        </div>
      </div>

      {/* Top example */}
      <div style={{ padding: '0 16px' }}>
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
          padding: '6px 6px 14px',
        }}>
          <div style={{
            fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
            color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
          }}>Top examples</div>
          <span style={{ fontSize: 11.5, color: MX.textMute }}>3 of 14 ›</span>
        </div>

        {[
          { game: 'vs. NightForge_99', san: 'Bc4', ply: '14.', loss: '−3.4' },
          { game: 'vs. otto77',        san: 'Qh4', ply: '11.', loss: '−2.8' },
          { game: 'vs. larsa',         san: 'Nxe5', ply: '17.', loss: '−2.1' },
        ].map((e, i) => (
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '32px 1fr auto 14px',
            alignItems: 'center', gap: 12,
            padding: '14px 6px',
            borderTop: i === 0 ? '1px solid ' + MX.line : '1px solid ' + MX.line,
            borderBottom: i === 2 ? '1px solid ' + MX.line : 'none',
          }}>
            <div style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 11, color: MX.textDim,
            }}>{e.ply}</div>
            <div>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14.5, color: MX.text }}>{e.san}</div>
              <div style={{ fontSize: 11.5, color: MX.textMute, marginTop: 2 }}>{e.game}</div>
            </div>
            <div style={{
              fontSize: 12, color: MX.them,
              fontFamily: 'JetBrains Mono, monospace',
            }}>{e.loss}</div>
            <span style={{ color: MX.textDim, fontSize: 12 }}>›</span>
          </div>
        ))}
      </div>

      <StatusOverlay />
      <TabBar active="dashboard" />
      <HomeIndicator />
    </PhoneScreen>
  );
}

function MMetric({ label, value, unit, divider }) {
  return (
    <div style={{
      paddingLeft: divider ? 14 : 0,
      borderLeft: divider ? '1px solid ' + MX.line : 'none',
    }}>
      <div style={{
        fontSize: 9.5, letterSpacing: '0.14em', textTransform: 'uppercase',
        color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
      }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 6 }}>
        <div style={{
          fontSize: 26, color: MX.text, letterSpacing: '-0.03em', fontWeight: 300,
        }}>{value}</div>
        {unit && <div style={{ fontSize: 11.5, color: MX.textMute }}>{unit}</div>}
      </div>
    </div>
  );
}

// Mobile orbit — vertical-friendly, central cue.
function MobileReplyOrbit() {
  return (
    <div style={{
      position: 'relative',
      height: 240,
      marginTop: 14, marginBottom: 4,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <svg viewBox="0 0 320 240" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        <ellipse cx="160" cy="120" rx="140" ry="100" fill="none" stroke="rgba(255,255,255,0.06)" strokeDasharray="2 5" />
        <ellipse cx="160" cy="120" rx="95" ry="70"  fill="none" stroke="rgba(255,255,255,0.05)" strokeDasharray="2 5" />
        <path d="M 55 50 Q 160 30 265 50" stroke={MX.you}  strokeOpacity="0.5" strokeWidth="1.1" fill="none" strokeDasharray="3 3" />
        <path d="M 265 50 Q 290 180 195 205" stroke={MX.them} strokeOpacity="0.5" strokeWidth="1.1" fill="none" strokeDasharray="3 3" />
        <path d="M 125 205 Q 30 175 55 50" stroke={MX.idea} strokeOpacity="0.4" strokeWidth="1.1" fill="none" strokeDasharray="3 3" />
      </svg>

      <div style={{
        position: 'absolute', left: '50%', top: '50%',
        transform: 'translate(-50%, -50%)',
        textAlign: 'center', maxWidth: 240, zIndex: 3,
      }}>
        <div style={{
          fontSize: 19, lineHeight: 1.15, letterSpacing: '-0.02em', color: MX.text,
        }}>
          You move <span style={{
            fontFamily: '"Instrument Serif", serif', fontStyle: 'italic', color: MX.you,
          }}>before</span> seeing the reply.
        </div>
      </div>

      <MOrbitNode style={{ left: '5%',  top: '8%'  }} kind="you"  label="You"  move="Bc4" />
      <MOrbitNode style={{ right: '5%', top: '8%'  }} kind="them" label="Them" move="Nxh5" />
      <MOrbitNode style={{ left: '28%', bottom: '0%' }} kind="idea" label="Idea" move="Nf3" />
    </div>
  );
}

function MOrbitNode({ kind, label, move, style }) {
  const color = kind === 'you' ? MX.you : kind === 'them' ? MX.them : MX.idea;
  return (
    <div style={{
      position: 'absolute', zIndex: 2,
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
      ...style,
    }}>
      <div style={{
        padding: '6px 10px', borderRadius: 999,
        background: '#0e0e0d',
        border: '1px solid ' + color + '50',
        display: 'flex', alignItems: 'center', gap: 7,
        boxShadow: '0 0 0 4px ' + color + '0a',
      }}>
        <span style={{
          width: 5, height: 5, borderRadius: '50%', background: color,
          boxShadow: '0 0 6px ' + color,
        }} />
        <span style={{
          fontSize: 12, color: MX.text,
          fontFamily: 'JetBrains Mono, monospace',
        }}>{move}</span>
      </div>
      <div style={{
        fontSize: 9.5, color: MX.textDim, letterSpacing: '0.12em',
        fontFamily: 'JetBrains Mono, monospace', textTransform: 'uppercase',
      }}>{label}</div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// Mobile: Mistake Lab list
// ───────────────────────────────────────────────────────────────

function MobileMistakeList() {
  const items = [
    { phase: 'OPN', ply: '14.', san: 'Bc4',  q: 'blunder', title: 'Reply ignored',         consequence: 'Nxh5 wins the queen' },
    { phase: 'OPN', ply: '11.', san: 'Qh4',  q: 'blunder', title: 'Queen out too early',   consequence: 'g3 traps and wins' },
    { phase: 'MID', ply: '17.', san: 'Nxe5', q: 'blunder', title: 'Loose piece left',      consequence: 'Qxe5 hangs the knight' },
    { phase: 'MID', ply: '22.', san: 'f3?',  q: 'inacc',   title: 'King shelter weakened', consequence: 'Allows Qh4 attack' },
    { phase: 'END', ply: '34.', san: 'Kf2',  q: 'inacc',   title: 'Passive king',          consequence: 'Loses tempo in pawn race' },
  ];

  return (
    <PhoneScreen>
      <PageHead
        eyebrow="14 spots · 4 patterns"
        title="Mistake Lab"
        right={<CircleBtn>⚙</CircleBtn>}
      />

      <div style={{ padding: '0 16px 14px', display: 'flex', gap: 8, overflowX: 'auto' }}>
        {[
          { label: 'Reply ignored', count: 6, tone: MX.you,  active: true },
          { label: 'Loose pieces',  count: 4, tone: MX.them },
          { label: 'King safety',   count: 3, tone: MX.idea },
          { label: 'Endgame',       count: 1, tone: MX.neutral },
        ].map((p, i) => (
          <div key={i} style={{
            padding: '8px 12px', borderRadius: 999,
            border: '1px solid ' + (p.active ? p.tone + '60' : MX.line),
            background: p.active ? p.tone + '10' : 'transparent',
            display: 'flex', alignItems: 'center', gap: 8,
            whiteSpace: 'nowrap',
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: p.tone }} />
            <span style={{ fontSize: 12.5, color: p.active ? MX.text : MX.textMute }}>{p.label}</span>
            <span style={{
              fontSize: 11, color: p.active ? p.tone : MX.textDim,
              fontFamily: 'JetBrains Mono, monospace',
            }}>{p.count}</span>
          </div>
        ))}
      </div>

      <div style={{ padding: '0 16px' }}>
        {items.map((it, i) => <MobileMistakeRow key={i} {...it} idx={i} />)}
      </div>

      <StatusOverlay />
      <TabBar active="lab" />
      <HomeIndicator />
    </PhoneScreen>
  );
}

function MobileMistakeRow({ phase, ply, san, q, title, consequence, idx }) {
  const qColor = q === 'blunder' ? MX.them : q === 'inacc' ? MX.you : MX.idea;
  return (
    <div style={{
      padding: '16px 6px',
      borderTop: idx === 0 ? '1px solid ' + MX.line : 'none',
      borderBottom: '1px solid ' + MX.line,
      display: 'grid',
      gridTemplateColumns: '34px 1fr 14px',
      gap: 12, alignItems: 'center',
    }}>
      <div style={{
        fontSize: 9.5, color: MX.textDim, letterSpacing: '0.12em',
        fontFamily: 'JetBrains Mono, monospace',
      }}>{phase}</div>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10.5, color: MX.textDim }}>{ply}</span>
          <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 15, color: MX.text }}>{san}</span>
          <span style={{ width: 5, height: 5, borderRadius: '50%', background: qColor }} />
          <span style={{
            fontSize: 9.5, color: MX.textDim, letterSpacing: '0.1em',
            fontFamily: 'JetBrains Mono, monospace',
            marginLeft: 'auto',
          }}>{title.toUpperCase()}</span>
        </div>
        <div style={{ fontSize: 12, color: MX.textMute, marginTop: 6 }}>{consequence}</div>
      </div>
      <span style={{ color: MX.textDim, fontSize: 14 }}>›</span>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// Mobile: Mistake detail (board + move map + drawer)
// ───────────────────────────────────────────────────────────────

function MobileMistakeDetail() {
  const fen = 'r1bqk2r/pppp1ppp/2n2n2/2b1p2Q/2B1P3/5N2/PPPP1PPP/RNB1K2R';
  return (
    <PhoneScreen padBottom={120}>
      <div style={{
        padding: '0 8px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 16px' }}>
          <CircleBtn>‹</CircleBtn>
          <div style={{ fontSize: 12, color: MX.textMute, fontFamily: 'JetBrains Mono, monospace' }}>
            03 / 14
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, padding: '4px 16px' }}>
          <CircleBtn>↺</CircleBtn>
          <CircleBtn>⋯</CircleBtn>
        </div>
      </div>

      <div style={{ padding: '14px 24px 8px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <MXPill tone="them">Blunder</MXPill>
          <MXPill tone="you" subtle>Reply ignored</MXPill>
        </div>
        <h2 style={{
          margin: 0, fontSize: 22, fontWeight: 400,
          letterSpacing: '-0.022em', lineHeight: 1.18,
          color: MX.text,
        }}>
          You moved <span style={{ fontFamily: 'JetBrains Mono, monospace', color: MX.you }}>Bc4</span> without seeing <span style={{ fontFamily: 'JetBrains Mono, monospace', color: MX.them }}>Nxh5</span>.
        </h2>
      </div>

      <div style={{ padding: '6px 16px 14px', display: 'flex', justifyContent: 'center' }}>
        <MXBoard
          fen={fen}
          size={361}
          highlights={{ h5: 'them', f6: 'them' }}
          arrows={[{ from: 'f6', to: 'h5', kind: 'them' }]}
        />
      </div>

      <MobileSegmented />

      <div style={{ padding: '8px 16px 18px' }}>
        <MXMoveMap
          you="Bc4" them="Nxh5" idea="Nf3"
          insight="The knight on f6 was already eyeing h5. Defend the queen before the bishop move."
          compact
        />
      </div>

      <div style={{ padding: '0 16px', display: 'flex', gap: 8 }}>
        <button style={{
          flex: 1, padding: '14px',
          borderRadius: 12, border: 'none',
          background: MX.text, color: '#0c0c0d',
          fontFamily: 'inherit', fontWeight: 500, fontSize: 14,
        }}>Train this position</button>
        <button style={{
          padding: '14px 16px',
          borderRadius: 12,
          border: '1px solid ' + MX.line,
          background: 'transparent', color: MX.text,
          fontFamily: 'inherit', fontSize: 14,
        }}>↗</button>
      </div>

      <div style={{ padding: '16px 16px 0' }}>
        <div style={{
          border: '1px solid ' + MX.line, borderRadius: 12,
          background: MX.surface,
          padding: '14px 16px',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div>
            <div style={{
              fontSize: 10.5, letterSpacing: '0.14em', textTransform: 'uppercase',
              color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
            }}>Engine lines</div>
            <div style={{ fontSize: 12, color: MX.textMute, marginTop: 4 }}>3 lines · depth 22</div>
          </div>
          <span style={{ color: MX.textMute }}>▾</span>
        </div>
      </div>

      <StatusOverlay />
      <TabBar active="lab" />
      <HomeIndicator />
    </PhoneScreen>
  );
}

function MobileSegmented() {
  const opts = [
    { id: 'your', label: 'Your move',  color: MX.you  },
    { id: 'them', label: 'Their reply', color: MX.them, active: true },
    { id: 'idea', label: 'Idea',       color: MX.idea },
  ];
  return (
    <div style={{ padding: '0 16px 14px' }}>
      <div style={{
        display: 'flex', padding: 3,
        borderRadius: 10,
        border: '1px solid ' + MX.line,
        background: MX.surface,
      }}>
        {opts.map(o => (
          <div key={o.id} style={{
            flex: 1, padding: '9px 8px',
            borderRadius: 7,
            background: o.active ? 'rgba(255,255,255,0.06)' : 'transparent',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            fontSize: 12.5, color: o.active ? MX.text : MX.textMute,
          }}>
            <span style={{
              width: 5, height: 5, borderRadius: '50%', background: o.color,
              opacity: o.active ? 1 : 0.5,
            }} />
            {o.label}
          </div>
        ))}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// Mobile: Drill
// ───────────────────────────────────────────────────────────────

function MobileDrill() {
  const fen = 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R';

  return (
    <PhoneScreen padBottom={150}>
      <div style={{
        padding: '4px 16px 0',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <CircleBtn>‹</CircleBtn>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{
            fontSize: 10.5, color: MX.textDim,
            fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.1em',
          }}>03 / 14</span>
        </div>
        <CircleBtn>⚙</CircleBtn>
      </div>

      <div style={{ padding: '14px 24px 6px' }}>
        <div style={{ display: 'flex', gap: 3 }}>
          {Array.from({ length: 14 }).map((_, i) => (
            <div key={i} style={{
              flex: 1, height: 3, borderRadius: 1.5,
              background:
                i < 2 ? MX.idea :
                i === 2 ? MX.text :
                'rgba(255,255,255,0.08)',
            }} />
          ))}
        </div>
      </div>

      <div style={{ padding: '18px 24px 14px', textAlign: 'center' }}>
        <div style={{
          fontSize: 10.5, letterSpacing: '0.18em', textTransform: 'uppercase',
          color: MX.you, fontFamily: 'JetBrains Mono, monospace', marginBottom: 8,
        }}>White to move</div>
        <div style={{
          fontSize: 20, color: MX.text, letterSpacing: '-0.02em', lineHeight: 1.22,
          fontWeight: 400,
        }}>
          Predict their <span style={{
            fontFamily: '"Instrument Serif", serif', fontStyle: 'italic', color: MX.them,
          }}>most forcing</span> reply.
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', padding: '0 16px 18px' }}>
        <MXBoard
          fen={fen}
          size={361}
          lastMove={{ from: 'e7', to: 'e5' }}
        />
      </div>

      <div style={{ padding: '0 24px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{
            fontSize: 9.5, letterSpacing: '0.14em', textTransform: 'uppercase',
            color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
          }}>Opening</div>
          <div style={{ fontSize: 13, color: MX.text, marginTop: 4 }}>Italian, Two Knights</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{
            fontSize: 9.5, letterSpacing: '0.14em', textTransform: 'uppercase',
            color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
          }}>Pattern</div>
          <div style={{ fontSize: 13, color: MX.you, marginTop: 4 }}>Reply ignored</div>
        </div>
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        padding: '14px 16px 100px',
        background: 'linear-gradient(180deg, rgba(12,12,13,0) 0%, rgba(12,12,13,0.95) 30%, rgba(12,12,13,1) 100%)',
        zIndex: 30,
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12,
          padding: '0 4px',
        }}>
          <div style={{
            fontSize: 11, color: MX.textMute,
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <div style={{
              width: 26, height: 14, borderRadius: 7,
              background: 'rgba(255,255,255,0.10)',
              position: 'relative',
            }}>
              <div style={{
                position: 'absolute', top: 2, left: 2,
                width: 10, height: 10, borderRadius: '50%', background: MX.text,
              }} />
            </div>
            Move map
          </div>
          <span style={{ marginLeft: 'auto', fontSize: 11, color: MX.textMute, fontFamily: 'JetBrains Mono, monospace' }}>00:42</span>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={{
            width: 48, padding: '14px 0',
            borderRadius: 12,
            border: '1px solid ' + MX.line,
            background: MX.surface, color: MX.textMute,
            fontFamily: 'inherit', fontSize: 14,
          }}>↺</button>
          <button style={{
            width: 48, padding: '14px 0',
            borderRadius: 12,
            border: '1px solid ' + MX.line,
            background: MX.surface, color: MX.textMute,
            fontFamily: 'inherit', fontSize: 14,
          }}>✦</button>
          <button style={{
            flex: 1, padding: '14px 0',
            borderRadius: 12,
            border: 'none',
            background: MX.text, color: '#0c0c0d',
            fontFamily: 'inherit', fontSize: 14, fontWeight: 500,
          }}>Commit move</button>
        </div>
      </div>

      <StatusOverlay />
      <TabBar active="drill" />
      <HomeIndicator />
    </PhoneScreen>
  );
}

// ───────────────────────────────────────────────────────────────
// Mobile: Games
// ───────────────────────────────────────────────────────────────

function MobileGames() {
  const games = [
    { opp: 'NightForge_99', result: 'L', tc: '10+0',  opening: 'Italian, Two Knights', date: 'Today',     mistakes: 3 },
    { opp: 'otto77',        result: 'W', tc: '15+10', opening: "Queen's Gambit Decl.", date: 'Today',     mistakes: 1 },
    { opp: 'larsa',         result: 'L', tc: '10+0',  opening: 'Caro-Kann Advance',     date: 'Yesterday', mistakes: 2 },
    { opp: 'm_g_b',         result: 'D', tc: '15+10', opening: 'Ruy Lopez, Berlin',     date: 'Yesterday', mistakes: 0 },
    { opp: 'kasparov_fan',  result: 'W', tc: '10+0',  opening: 'Scotch Game',           date: 'May 18',    mistakes: 1 },
    { opp: 'pearlsnap',     result: 'L', tc: '10+0',  opening: 'Sicilian, Najdorf',     date: 'May 18',    mistakes: 4 },
  ];
  return (
    <PhoneScreen>
      <PageHead
        eyebrow="74 games · last 30 days"
        title="Games"
        right={<CircleBtn>↗</CircleBtn>}
      />

      <div style={{ padding: '0 16px 14px', display: 'flex', gap: 8 }}>
        {['All', 'With mistakes', 'White', 'Black'].map((f, i) => (
          <div key={f} style={{
            padding: '7px 12px', borderRadius: 999,
            border: '1px solid ' + (i === 1 ? 'rgba(255,255,255,0.18)' : MX.line),
            background: i === 1 ? 'rgba(255,255,255,0.04)' : 'transparent',
            fontSize: 12, color: i === 1 ? MX.text : MX.textMute,
            whiteSpace: 'nowrap',
          }}>{f}</div>
        ))}
      </div>

      <div style={{ padding: '0 16px' }}>
        {games.map((g, i) => (
          <MobileGameRow key={i} {...g} idx={i} />
        ))}
      </div>

      <StatusOverlay />
      <TabBar active="games" />
      <HomeIndicator />
    </PhoneScreen>
  );
}

function MobileGameRow({ opp, result, tc, opening, date, mistakes, idx }) {
  const resultColor = result === 'W' ? MX.idea : result === 'L' ? MX.them : MX.textMute;
  return (
    <div style={{
      padding: '16px 6px',
      display: 'grid',
      gridTemplateColumns: '22px 1fr auto 14px',
      gap: 14, alignItems: 'center',
      borderTop: idx === 0 ? '1px solid ' + MX.line : 'none',
      borderBottom: '1px solid ' + MX.line,
    }}>
      <div style={{
        width: 22, height: 22, borderRadius: 5,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: resultColor + '18', color: resultColor,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 11, fontWeight: 600,
      }}>{result}</div>
      <div>
        <div style={{ fontSize: 14, color: MX.text }}>{opp}</div>
        <div style={{ fontSize: 11.5, color: MX.textMute, marginTop: 3 }}>{opening} · {tc} · {date}</div>
      </div>
      {mistakes > 0 ? (
        <span style={{
          padding: '2px 6px', borderRadius: 4,
          background: MX.them + '22', color: MX.them,
          fontSize: 11, fontFamily: 'JetBrains Mono, monospace',
        }}>{mistakes}</span>
      ) : (
        <span style={{ color: MX.textDim, fontSize: 11 }}>—</span>
      )}
      <span style={{ color: MX.textDim, fontSize: 12 }}>›</span>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// Mobile: Analysis
// ───────────────────────────────────────────────────────────────

function MobileAnalysis() {
  const fen = 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R';
  return (
    <PhoneScreen padBottom={110}>
      <div style={{
        padding: '4px 16px 0',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <CircleBtn>‹</CircleBtn>
        <div style={{ fontSize: 12, color: MX.textMute }}>vs NightForge · #9</div>
        <CircleBtn>⇅</CircleBtn>
      </div>

      <div style={{ padding: '18px 16px 14px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <div>
          <div style={{
            fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
            color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
          }}>Evaluation</div>
          <div style={{
            fontSize: 38, color: MX.text, letterSpacing: '-0.03em',
            fontWeight: 300, fontFamily: 'JetBrains Mono, monospace',
            marginTop: 4,
          }}>+0.4</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{
            fontSize: 10.5, letterSpacing: '0.14em', textTransform: 'uppercase',
            color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
          }}>Depth</div>
          <div style={{ fontSize: 16, color: MX.text, marginTop: 4, fontFamily: 'JetBrains Mono, monospace' }}>24</div>
        </div>
      </div>

      <div style={{ padding: '0 16px 18px', display: 'flex', justifyContent: 'center', gap: 14 }}>
        <MXEval score={0.4} height={361} width={10} />
        <MXBoard
          fen={fen}
          size={313}
          lastMove={{ from: 'f1', to: 'c4' }}
          highlights={{ c4: 'sel' }}
        />
      </div>

      <div style={{ padding: '0 16px 10px', display: 'flex', justifyContent: 'space-around' }}>
        {['⏮', '◀', '▶', '⏭'].map(ic => (
          <div key={ic} style={{
            width: 56, height: 38, borderRadius: 10,
            border: '1px solid ' + MX.line, background: MX.surface,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: MX.textMute, fontSize: 12,
          }}>{ic}</div>
        ))}
      </div>

      <div style={{ padding: '8px 16px 0' }}>
        <div style={{
          border: '1px solid ' + MX.line, borderRadius: 12,
          background: MX.surface, overflow: 'hidden',
        }}>
          <div style={{
            padding: '12px 16px',
            borderBottom: '1px solid ' + MX.line,
            display: 'flex', justifyContent: 'space-between',
          }}>
            <div style={{
              fontSize: 10.5, letterSpacing: '0.14em', textTransform: 'uppercase',
              color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
            }}>Variations</div>
            <span style={{ fontSize: 10.5, color: MX.textDim, fontFamily: 'JetBrains Mono, monospace' }}>SF 16</span>
          </div>
          {[
            { score: '+0.4', pv: 'O-O d6 h3 a6 a4 Ba7', best: true },
            { score: '+0.3', pv: 'c3 d6 h3 a6 Bb3 Ba7' },
            { score: '+0.2', pv: 'd3 h6 c3 d6 h3 a6' },
          ].map((l, i) => (
            <div key={i} style={{
              padding: '11px 16px',
              display: 'flex', alignItems: 'center', gap: 14,
              borderTop: i === 0 ? 'none' : '1px solid ' + MX.line,
              background: l.best ? 'rgba(156,182,107,0.04)' : 'transparent',
            }}>
              <span style={{
                width: 36, fontSize: 12, color: l.best ? MX.idea : MX.text,
                fontFamily: 'JetBrains Mono, monospace',
              }}>{l.score}</span>
              <span style={{
                flex: 1, fontSize: 11.5, color: MX.textMute,
                fontFamily: 'JetBrains Mono, monospace',
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>{l.pv}</span>
            </div>
          ))}
        </div>
      </div>

      <StatusOverlay />
      <TabBar active="lab" />
      <HomeIndicator />
    </PhoneScreen>
  );
}

// ───────────────────────────────────────────────────────────────
// Mobile: Import / first-run
// ───────────────────────────────────────────────────────────────

function MobileImport() {
  return (
    <PhoneScreen padBottom={20} scroll={false}>
      <div style={{ padding: '24px 24px 12px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 26, height: 26, borderRadius: 6,
          background: 'linear-gradient(135deg, #EFEAD8 50%, #2A2620 50%)',
          boxShadow: '0 0 0 1px rgba(255,255,255,0.08)',
        }} />
        <div style={{ fontSize: 14 }}>
          Pattern <span style={{ fontFamily: '"Instrument Serif", serif', fontStyle: 'italic' }}>Coach</span>
        </div>
      </div>

      <div style={{ padding: '40px 24px 24px' }}>
        <div style={{
          fontSize: 10.5, letterSpacing: '0.18em', textTransform: 'uppercase',
          color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
          marginBottom: 18,
        }}>Connect</div>
        <h1 style={{
          margin: 0, fontSize: 34, fontWeight: 400,
          letterSpacing: '-0.028em', lineHeight: 1.06,
          color: MX.text,
        }}>
          Bring in <span style={{ fontFamily: '"Instrument Serif", serif', fontStyle: 'italic', color: MX.you }}>your games.</span> We'll find the shapes you keep <span style={{ fontFamily: '"Instrument Serif", serif', fontStyle: 'italic', color: MX.them }}>misreading.</span>
        </h1>
      </div>

      <div style={{ padding: '8px 16px 0' }}>
        <MobileFormRow label="Chess.com username">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 14, color: MX.text, fontFamily: 'JetBrains Mono, monospace' }}>magrios</span>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: MX.idea, boxShadow: '0 0 6px ' + MX.idea }} />
          </div>
        </MobileFormRow>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 10 }}>
          <MobileFormRow label="Range">
            <div style={{ fontSize: 13.5, color: MX.text }}>3 months</div>
          </MobileFormRow>
          <MobileFormRow label="Cap">
            <div style={{ fontSize: 13.5, color: MX.text }}>200 games</div>
          </MobileFormRow>
        </div>
        <MobileFormRow label="Time controls" style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {['Bullet', 'Blitz', 'Rapid', 'Daily'].map((t, i) => (
              <span key={t} style={{
                padding: '3px 9px',
                borderRadius: 4,
                background: i === 2 ? MX.text : 'transparent',
                color: i === 2 ? '#0c0c0d' : MX.textMute,
                border: '1px solid ' + (i === 2 ? MX.text : MX.line),
                fontSize: 11.5, fontFamily: 'JetBrains Mono, monospace',
              }}>{t}</span>
            ))}
          </div>
        </MobileFormRow>
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        padding: '20px 16px 38px',
        background: 'linear-gradient(180deg, rgba(12,12,13,0) 0%, rgba(12,12,13,1) 30%)',
      }}>
        <button style={{
          width: '100%', padding: '15px',
          borderRadius: 12, border: 'none',
          background: MX.text, color: '#0c0c0d',
          fontFamily: 'inherit', fontWeight: 500, fontSize: 14.5,
        }}>Sync 74 games  ↗</button>
        <div style={{
          display: 'flex', justifyContent: 'center', gap: 24, marginTop: 14,
          fontSize: 12.5, color: MX.textMute,
        }}>
          <span>Paste PGN</span>
          <span style={{ color: MX.textDim }}>·</span>
          <span>Try sample</span>
        </div>
      </div>

      <StatusOverlay />
      <HomeIndicator />
    </PhoneScreen>
  );
}

function MobileFormRow({ label, children, style }) {
  return (
    <div style={{
      padding: '12px 14px',
      borderRadius: 12,
      border: '1px solid ' + MX.line,
      background: MX.surface,
      ...(style || {}),
    }}>
      <div style={{
        fontSize: 9.5, letterSpacing: '0.14em', textTransform: 'uppercase',
        color: MX.textDim, fontFamily: 'JetBrains Mono, monospace',
        marginBottom: 4,
      }}>{label}</div>
      {children}
    </div>
  );
}

// ───────────────────────────────────────────────────────────────

Object.assign(window, {
  MobileDashboard, MobileMistakeList, MobileMistakeDetail,
  MobileDrill, MobileGames, MobileAnalysis, MobileImport,
  PHONE_W, PHONE_H,
});

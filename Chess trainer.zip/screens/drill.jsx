// Drill Mode — recall practice. Board-first, minimal chrome.

const { PC_COLORS: DC, Board: DBoard, TopBar: DTopBar, Btn: DBtn, Pill: DPill, ScreenFrame: DFrame } = window;

function DrillScreen() {
  // Italian: pre-blunder position, white to move (the user is being asked
  // to predict the safer idea before committing).
  const fen = 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R';

  return (
    <DFrame nav="drill">
      <DTopBar
        eyebrow="Reply ignored · spot 3 of 14"
        title="Drill"
        right={
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <ToggleSwitch label="Move map" value={false} />
            <DBtn ghost small icon="⚙">Filters</DBtn>
          </div>
        }
      />

      <div style={{
        flex: 1, display: 'grid',
        gridTemplateColumns: '1fr',
        minHeight: 0,
      }}>
        <div style={{
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          padding: '12px 40px 40px',
          gap: 20,
        }}>
          {/* progress strip */}
          <div style={{
            width: '100%', maxWidth: 720,
            display: 'flex', alignItems: 'center', gap: 10,
            marginBottom: 8,
          }}>
            <div style={{
              fontSize: 10.5, color: DC.textDim,
              fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.1em',
            }}>03 / 14</div>
            <div style={{ flex: 1, display: 'flex', gap: 3 }}>
              {Array.from({ length: 14 }).map((_, i) => (
                <div key={i} style={{
                  flex: 1, height: 3, borderRadius: 1.5,
                  background:
                    i < 2 ? DC.idea :
                    i === 2 ? DC.text :
                    'rgba(255,255,255,0.08)',
                }} />
              ))}
            </div>
            <div style={{
              fontSize: 10.5, color: DC.textDim,
              fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.1em',
            }}>00:42</div>
          </div>

          {/* prompt above board */}
          <div style={{
            textAlign: 'center', marginBottom: 4,
          }}>
            <div style={{
              fontSize: 10.5, letterSpacing: '0.18em', textTransform: 'uppercase',
              color: DC.you, fontFamily: 'JetBrains Mono, monospace',
              marginBottom: 10,
            }}>White to move</div>
            <div style={{
              fontSize: 24, color: DC.text, letterSpacing: '-0.022em',
              fontWeight: 400,
            }}>
              Predict their <span style={{
                fontFamily: '"Instrument Serif", serif', fontStyle: 'italic',
                color: DC.them,
              }}>most forcing</span> reply.
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 28 }}>
            {/* side rail: side to move + opening + hint */}
            <SideMeta />

            <DBoard
              fen={fen}
              size={500}
              lastMove={{ from: 'e7', to: 'e5' }}
            />

            {/* candidates panel */}
            <Candidates />
          </div>

          {/* controls */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10,
            marginTop: 10,
          }}>
            <DBtn small icon="←">Prev</DBtn>
            <DBtn small icon="↺">Reset</DBtn>
            <DBtn small icon="✨">Hint</DBtn>
            <DBtn small>Skip</DBtn>
            <div style={{ width: 1, height: 18, background: DC.line, margin: '0 4px' }} />
            <DBtn primary icon="→" style={{ minWidth: 120 }}>Commit move</DBtn>
          </div>
        </div>
      </div>
    </DFrame>
  );
}

function SideMeta() {
  return (
    <div style={{
      width: 180, display: 'flex', flexDirection: 'column', gap: 22,
      paddingTop: 16,
    }}>
      <Meta label="Side" value="White" accent />
      <Meta label="Phase" value="Opening" />
      <Meta label="Opening" value="Italian, Two Knights" />
      <Meta label="Pattern" value="Reply ignored" tone="you" />
    </div>
  );
}

function Meta({ label, value, accent, tone }) {
  const color = tone === 'you' ? DC.you : DC.text;
  return (
    <div>
      <div style={{
        fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase',
        color: DC.textDim, fontFamily: 'JetBrains Mono, monospace',
      }}>{label}</div>
      <div style={{
        fontSize: 14, color, marginTop: 6,
        letterSpacing: '-0.005em',
      }}>{value}</div>
    </div>
  );
}

function Candidates() {
  // Suggested candidate moves the user can click. Not best moves —
  // just options the system asks them to commit before showing consequence.
  const moves = [
    { san: 'Nc3', purpose: 'develops' },
    { san: 'Bc4', purpose: 'develops' },
    { san: 'h3',  purpose: 'prevents Bg4 pin' },
    { san: 'd4',  purpose: 'contests center' },
    { san: 'Bg5', purpose: 'pins the knight' },
  ];
  return (
    <div style={{
      width: 200, display: 'flex', flexDirection: 'column', gap: 4,
      paddingTop: 16,
    }}>
      <div style={{
        fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase',
        color: DC.textDim, fontFamily: 'JetBrains Mono, monospace',
        marginBottom: 8,
      }}>Your candidates</div>
      {moves.map((m, i) => (
        <div key={i} style={{
          padding: '10px 12px',
          border: '1px solid ' + (i === 0 ? 'rgba(255,255,255,0.18)' : DC.line),
          background: i === 0 ? 'rgba(255,255,255,0.04)' : 'transparent',
          borderRadius: 6,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 13.5, color: i === 0 ? DC.text : DC.textMute,
            }}>{m.san}</span>
          </div>
          <span style={{ fontSize: 10.5, color: DC.textDim }}>{m.purpose}</span>
        </div>
      ))}
      <div style={{
        marginTop: 8, padding: '10px 12px',
        borderRadius: 6, border: '1px dashed ' + DC.line,
        fontSize: 11, color: DC.textDim, textAlign: 'center',
      }}>or play on the board</div>
    </div>
  );
}

function ToggleSwitch({ label, value }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ fontSize: 12, color: DC.textMute }}>{label}</span>
      <div style={{
        width: 28, height: 16, borderRadius: 8,
        background: value ? DC.idea : 'rgba(255,255,255,0.10)',
        position: 'relative',
        transition: 'background 0.2s',
      }}>
        <div style={{
          position: 'absolute', top: 2, left: value ? 14 : 2,
          width: 12, height: 12, borderRadius: '50%',
          background: DC.text,
          transition: 'left 0.2s',
        }} />
      </div>
    </div>
  );
}

window.DrillScreen = DrillScreen;

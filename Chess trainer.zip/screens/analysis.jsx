// Analysis Board — exploration surface. Board + eval bar + move log + drawer.

const { PC_COLORS: AC, Board: ABoard, EvalBar: AEval, TopBar: ATopBar, Btn: ABtn, Pill: APill, ScreenFrame: AFrame } = window;

function AnalysisScreen() {
  const fen = 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R';

  return (
    <AFrame nav="analysis">
      <ATopBar
        eyebrow="From: vs NightForge_99  ·  move 9"
        title="Analysis"
        right={
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <FenInput />
            <ABtn small icon="↺">Reset</ABtn>
            <ABtn small icon="⇅">Flip</ABtn>
          </div>
        }
      />

      <div style={{
        flex: 1, display: 'grid',
        gridTemplateColumns: '1fr 360px',
        gap: 0, minHeight: 0,
      }}>
        {/* board column */}
        <div style={{
          padding: '28px 36px',
          display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
          gap: 18,
        }}>
          <AEval score={0.4} height={500} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <ABoard
              fen={fen}
              size={500}
              lastMove={{ from: 'f1', to: 'c4' }}
              highlights={{ c4: 'sel' }}
            />
            <BoardToolbar />
          </div>
        </div>

        {/* side panel */}
        <div style={{
          borderLeft: '1px solid ' + AC.line,
          display: 'flex', flexDirection: 'column',
          minWidth: 0,
        }}>
          <EvalSummary />
          <MoveTree />
          <EngineDrawer />
        </div>
      </div>
    </AFrame>
  );
}

function FenInput() {
  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      padding: '6px 10px', borderRadius: 6,
      border: '1px solid ' + AC.line,
      gap: 8, width: 360,
    }}>
      <span style={{
        fontSize: 10.5, color: AC.textDim,
        fontFamily: 'JetBrains Mono, monospace',
        letterSpacing: '0.14em', textTransform: 'uppercase',
      }}>FEN</span>
      <span style={{
        fontSize: 12, color: AC.textMute,
        fontFamily: 'JetBrains Mono, monospace',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        flex: 1,
      }}>r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 4 5</span>
      <span style={{
        fontSize: 11, color: AC.textDim,
        fontFamily: 'JetBrains Mono, monospace',
        paddingLeft: 8, borderLeft: '1px solid ' + AC.line,
      }}>⎘</span>
    </div>
  );
}

function BoardToolbar() {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '4px 0',
    }}>
      <ToolBtn icon="⏮" />
      <ToolBtn icon="◀" />
      <ToolBtn icon="▶" />
      <ToolBtn icon="⏭" />
      <div style={{ flex: 1 }} />
      <ToggleA label="Learn mode" value={false} />
      <ToggleA label="Arrows" value={true} />
    </div>
  );
}

function ToolBtn({ icon }) {
  return (
    <div style={{
      width: 32, height: 32, borderRadius: 6,
      border: '1px solid ' + AC.line,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: AC.textMute, fontSize: 11,
    }}>{icon}</div>
  );
}

function ToggleA({ label, value }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{ fontSize: 11.5, color: AC.textMute }}>{label}</span>
      <div style={{
        width: 26, height: 14, borderRadius: 7,
        background: value ? AC.idea : 'rgba(255,255,255,0.10)',
        position: 'relative',
      }}>
        <div style={{
          position: 'absolute', top: 2, left: value ? 14 : 2,
          width: 10, height: 10, borderRadius: '50%',
          background: AC.text,
        }} />
      </div>
    </div>
  );
}

function EvalSummary() {
  return (
    <div style={{
      padding: '22px 24px',
      borderBottom: '1px solid ' + AC.line,
    }}>
      <div style={{
        fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
        color: AC.textDim, fontFamily: 'JetBrains Mono, monospace',
      }}>Evaluation</div>
      <div style={{
        display: 'flex', alignItems: 'baseline', gap: 12, marginTop: 8,
      }}>
        <div style={{
          fontSize: 42, color: AC.text, letterSpacing: '-0.03em',
          fontWeight: 300,
          fontFamily: 'JetBrains Mono, monospace',
        }}>+0.4</div>
        <div style={{
          fontSize: 11.5, color: AC.textMute,
          fontFamily: 'JetBrains Mono, monospace',
        }}>depth 24</div>
      </div>
      <div style={{
        fontSize: 12, color: AC.textMute, marginTop: 6, letterSpacing: '-0.003em',
      }}>White is slightly better. Equal play.</div>
    </div>
  );
}

function MoveTree() {
  const lines = [
    { ply: '5.', side: 'w', san: 'O-O',  best: true },
    { ply: '5.', side: 'w', san: 'c3',   alt: true },
    { ply: '5.', side: 'w', san: 'd3',   alt: true },
    { ply: '6.', side: 'b', san: 'd6',   best: true },
    { ply: '6.', side: 'b', san: 'Bxf2+', sideline: true },
  ];
  return (
    <div style={{
      flex: 1,
      borderBottom: '1px solid ' + AC.line,
      overflow: 'auto',
    }}>
      <div style={{
        padding: '16px 24px 8px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div style={{
          fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
          color: AC.textDim, fontFamily: 'JetBrains Mono, monospace',
        }}>Variations</div>
        <span style={{
          fontSize: 10.5, color: AC.textDim,
          fontFamily: 'JetBrains Mono, monospace',
        }}>MultiPV 3</span>
      </div>
      <div>
        {lines.map((l, i) => (
          <div key={i} style={{
            padding: '8px 24px',
            display: 'grid',
            gridTemplateColumns: '34px 14px 1fr auto',
            gap: 10, alignItems: 'center',
            borderTop: '1px solid ' + AC.line,
            opacity: l.sideline ? 0.45 : 1,
            background: l.best ? 'rgba(156,182,107,0.04)' : 'transparent',
          }}>
            <span style={{
              fontSize: 10.5, color: AC.textDim,
              fontFamily: 'JetBrains Mono, monospace',
            }}>{l.ply}</span>
            <span style={{
              fontSize: 10, color: l.side === 'w' ? AC.text : AC.textMute,
            }}>{l.side === 'w' ? '○' : '●'}</span>
            <span style={{
              fontSize: 13, color: AC.text,
              fontFamily: 'JetBrains Mono, monospace',
              fontWeight: l.best ? 500 : 400,
            }}>{l.san}</span>
            {l.best && <APill tone="idea" subtle>Best</APill>}
            {l.alt && <span style={{ fontSize: 10.5, color: AC.textDim, fontFamily: 'JetBrains Mono, monospace' }}>+0.3</span>}
            {l.sideline && <span style={{ fontSize: 10.5, color: AC.them, fontFamily: 'JetBrains Mono, monospace' }}>-3.1</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

function EngineDrawer() {
  return (
    <div>
      <div style={{
        padding: '14px 24px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        borderBottom: '1px solid ' + AC.line,
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <span style={{ fontSize: 10, color: AC.textMute }}>▾</span>
          <div style={{
            fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
            color: AC.textMute, fontFamily: 'JetBrains Mono, monospace',
          }}>Engine lines</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{
            width: 5, height: 5, borderRadius: '50%', background: AC.idea,
            boxShadow: '0 0 4px ' + AC.idea,
          }} />
          <span style={{
            fontSize: 10.5, color: AC.textMute,
            fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.06em',
          }}>SF 16 · 24</span>
        </div>
      </div>
      <div style={{ padding: '12px 24px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[
          { score: '+0.4', pv: 'O-O d6 h3 a6 a4 Ba7 Nc3' },
          { score: '+0.3', pv: 'c3 d6 h3 a6 Bb3 Ba7 Re1' },
          { score: '+0.2', pv: 'd3 h6 c3 d6 h3 a6 a4' },
        ].map((l, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{
              width: 44, fontSize: 11.5, color: AC.text,
              fontFamily: 'JetBrains Mono, monospace',
            }}>{l.score}</span>
            <span style={{
              fontSize: 11.5, color: AC.textMute,
              fontFamily: 'JetBrains Mono, monospace',
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              flex: 1,
            }}>{l.pv}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

window.AnalysisScreen = AnalysisScreen;

// Shared primitives for Pattern Coach surfaces.
// Globals exposed to other screens at bottom of file.

const COLORS = {
  bg: '#0c0c0d',
  surface: '#141416',
  surface2: '#1c1c1f',
  line: 'rgba(255,255,255,0.06)',
  lineStrong: 'rgba(255,255,255,0.12)',
  text: '#ECEBE6',
  textMute: '#8A8A85',
  textDim: '#54544F',
  you: '#E9A24A',
  them: '#E2604A',
  idea: '#9CB66B',
  neutral: '#6B6B66',
  squareLight: '#D9CFB8',
  squareDark: '#5B5147'
};

// ---- Board settings context --------------------------------------------
// Shared, tweakable settings that every Board reads.

const BOARD_THEMES = {
  warm: { light: '#D9CFB8', dark: '#5B5147' },
  slate: { light: '#C8CBD0', dark: '#3F454C' },
  classic: { light: '#EBD9B0', dark: '#7E8C4F' },
  walnut: { light: '#E3D3B8', dark: '#3D2D1F' }
};

const BoardSettingsContext = React.createContext({
  analysePos: 'top-right',
  analyseStyle: 'pill',
  boardTheme: 'warm',
  showCoords: true
});

// ---- Chess board ---------------------------------------------------------

// Map FEN-like char to unicode piece.
const PIECE = {
  K: '♔', Q: '♕', R: '♖', B: '♗', N: '♘', P: '♙',
  k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟'
};

// Parse a board portion of FEN into 8x8 grid (rank 8 first).
function parseFen(fen) {
  const board = fen.split(' ')[0];
  const ranks = board.split('/');
  return ranks.map((rank) => {
    const row = [];
    for (const ch of rank) {
      if (/\d/.test(ch)) {
        for (let i = 0; i < +ch; i++) row.push(null);
      } else {
        row.push(ch);
      }
    }
    return row;
  });
}

function squareName(file, rank) {
  // file 0..7 -> a..h; rank 0..7 from top (rank 8) -> 7..0
  return 'abcdefgh'[file] + (8 - rank);
}

// Highlights: { e4: 'you' | 'them' | 'idea' | 'sel' | 'target', ... }
// Arrows: [{ from: 'e2', to: 'e4', kind: 'you' | 'them' | 'idea' }]
function Board({
  fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR',
  highlights = {},
  arrows = [],
  lastMove = null,
  size = 480,
  showCoords,
  flipped = false,
  analyse = true
}) {
  const settings = React.useContext(BoardSettingsContext);
  const theme = BOARD_THEMES[settings.boardTheme] || BOARD_THEMES.warm;
  const coords = showCoords ?? settings.showCoords;

  const grid = React.useMemo(() => {
    let g = parseFen(fen);
    if (flipped) {
      g = g.slice().reverse().map((r) => r.slice().reverse());
    }
    return g;
  }, [fen, flipped]);

  const sq = size / 8;

  // Convert a square name to {x,y} center in board pixels.
  const sqToXY = (name) => {
    const file = 'abcdefgh'.indexOf(name[0]);
    const rank = +name[1];
    const col = flipped ? 7 - file : file;
    const row = flipped ? rank - 1 : 8 - rank;
    return { x: col * sq + sq / 2, y: row * sq + sq / 2 };
  };

  const arrowColor = (kind) =>
  kind === 'you' ? COLORS.you :
  kind === 'them' ? COLORS.them :
  kind === 'idea' ? COLORS.idea :
  COLORS.neutral;

  return (
    <div
      style={{
        width: size, height: size, position: 'relative',
        boxShadow: '0 30px 60px -20px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.04)',
        borderRadius: 6
      }}>
      
      <div style={{
        position: 'absolute', inset: 0,
        borderRadius: 6,
        overflow: 'hidden'
      }}>
      {/* squares */}
      <div style={{
          position: 'absolute', inset: 0,
          display: 'grid',
          gridTemplateColumns: 'repeat(8, 1fr)',
          gridTemplateRows: 'repeat(8, 1fr)'
        }}>
        {grid.flatMap((row, r) => row.map((piece, c) => {
            const isLight = (r + c) % 2 === 0;
            const fileIdx = flipped ? 7 - c : c;
            const rankIdx = flipped ? r : 7 - r;
            const name = 'abcdefgh'[fileIdx] + (rankIdx + 1);
            const hi = highlights[name];
            const isLast = lastMove && (lastMove.from === name || lastMove.to === name);

            let overlay = null;
            if (hi === 'you') overlay = 'rgba(233,162,74,0.28)';
            if (hi === 'them') overlay = 'rgba(226,96,74,0.32)';
            if (hi === 'idea') overlay = 'rgba(156,182,107,0.28)';
            if (hi === 'sel') overlay = 'rgba(255,255,255,0.10)';
            if (hi === 'target') overlay = 'rgba(226,96,74,0.18)';
            if (hi === 'safe') overlay = 'rgba(156,182,107,0.18)';
            if (isLast && !overlay) overlay = 'rgba(233,162,74,0.14)';

            const isDot = hi === 'dot';
            const isCap = hi === 'capture';

            return (
              <div key={r + '-' + c} style={{
                position: 'relative',
                background: isLight ? theme.light : theme.dark,
                display: 'flex', alignItems: 'center', justifyContent: 'center'
              }}>
              {overlay &&
                <div style={{ position: 'absolute', inset: 0, background: overlay }} />
                }
              {isDot &&
                <div style={{
                  position: 'absolute',
                  width: sq * 0.22, height: sq * 0.22, borderRadius: '50%',
                  background: 'rgba(20,20,20,0.22)'
                }} />
                }
              {isCap &&
                <div style={{
                  position: 'absolute', inset: sq * 0.06,
                  borderRadius: '50%',
                  boxShadow: 'inset 0 0 0 ' + sq * 0.08 + 'px rgba(20,20,20,0.22)'
                }} />
                }
              {coords && c === 0 &&
                <div style={{
                  position: 'absolute', top: 2, left: 4,
                  fontSize: Math.max(9, sq * 0.13),
                  fontFamily: 'JetBrains Mono, monospace',
                  color: isLight ? 'rgba(60,50,40,0.55)' : 'rgba(245,240,230,0.55)',
                  lineHeight: 1
                }}>{rankIdx + 1}</div>
                }
              {coords && r === 7 &&
                <div style={{
                  position: 'absolute', bottom: 2, right: 4,
                  fontSize: Math.max(9, sq * 0.13),
                  fontFamily: 'JetBrains Mono, monospace',
                  color: isLight ? 'rgba(60,50,40,0.55)' : 'rgba(245,240,230,0.55)',
                  lineHeight: 1
                }}>{'abcdefgh'[fileIdx]}</div>
                }
              {piece &&
                <span style={{
                  fontSize: sq * 0.78,
                  lineHeight: 1,
                  color: piece === piece.toUpperCase() ? '#FAF7EE' : '#1C1A16',
                  textShadow: piece === piece.toUpperCase() ?
                  '0 1px 0 rgba(0,0,0,0.35), 0 2px 6px rgba(0,0,0,0.18)' :
                  '0 1px 0 rgba(255,255,255,0.18)',
                  fontFamily: '"Segoe UI Symbol", "Apple Symbols", "Noto Sans Symbols 2", serif',
                  userSelect: 'none',
                  position: 'relative'
                }}>{PIECE[piece]}</span>
                }
            </div>);

          }))}
      </div>

      {/* arrows */}
      {arrows.length > 0 &&
        <svg viewBox={`0 0 ${size} ${size}`} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
          <defs>
            {['you', 'them', 'idea', 'neutral'].map((k) =>
            <marker key={k} id={`ah-${k}`} viewBox="0 0 10 10" refX="6" refY="5"
            markerWidth="5" markerHeight="5" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill={arrowColor(k)} />
              </marker>
            )}
          </defs>
          {arrows.map((a, i) => {
            const f = sqToXY(a.from);
            const t = sqToXY(a.to);
            const c = arrowColor(a.kind);
            return (
              <line key={i}
              x1={f.x} y1={f.y} x2={t.x} y2={t.y}
              stroke={c}
              strokeWidth={Math.max(6, sq * 0.14)}
              strokeLinecap="round"
              opacity="0.82"
              markerEnd={`url(#ah-${a.kind || 'neutral'})`} />);


          })}
        </svg>
        }
      </div>

      {/* Analyse overlay — anchored to the same corner on every board */}
      {analyse &&
      <AnalyseChip
        boardSize={size}
        position={settings.analysePos}
        variant={settings.analyseStyle} />

      }
    </div>);

}

// ---- Analyse button -----------------------------------------------------
// Anchored to every Board. Position and style come from BoardSettingsContext
// (driven by the Tweaks panel) so every chess surface in the app keeps the
// button in the same corner.

function AnalyseChip({ boardSize = 480, position = 'top-right', variant = 'pill' }) {
  const isSmall = boardSize < 360;

  const positions = {
    'top-right': { top: 8, right: 8 },
    'bottom-right': { bottom: 8, right: 8 },
    'outside-top': { top: -14, right: 0 }
  };

  const base = {
    position: 'absolute', zIndex: 5,
    display: 'inline-flex', alignItems: 'center', gap: 6,
    fontFamily: '"Hanken Grotesk", system-ui, sans-serif',
    fontSize: isSmall ? 10.5 : 11.5,
    fontWeight: 500, lineHeight: 1,
    cursor: 'pointer', userSelect: 'none',
    ...positions[position]
  };

  const fg = variant === 'minimal' ? '#FAF7EE' : '#0c0c0d';

  if (variant === 'minimal') {
    Object.assign(base, {
      padding: '5px 9px',
      color: fg,
      background: 'rgba(12,12,13,0.6)',
      backdropFilter: 'blur(10px)',
      WebkitBackdropFilter: 'blur(10px)',
      borderRadius: 5,
      border: '1px solid rgba(255,255,255,0.10)'
    });
  } else {
    Object.assign(base, {
      padding: isSmall ? '5px 10px 5px 9px' : '6px 12px 6px 10px',
      color: fg,
      background: 'rgba(236,235,230,0.94)',
      backdropFilter: 'blur(10px)',
      WebkitBackdropFilter: 'blur(10px)',
      borderRadius: 999,
      boxShadow: '0 6px 16px rgba(0,0,0,0.32), inset 0 0 0 1px rgba(255,255,255,0.5)'
    });
  }

  return (
    <div style={{ ...base, padding: "6px 12px 6px 10px", height: "25px" }}>
      <svg width={isSmall ? 10 : 11} height={isSmall ? 10 : 11} viewBox="0 0 12 12" fill="none">
        <circle cx="5" cy="5" r="3.2" stroke={fg} strokeWidth="1.3" />
        <path d="M 7.6 7.6 L 10 10" stroke={fg} strokeWidth="1.3" strokeLinecap="round" />
      </svg>
      <span>Analyse</span>
    </div>);

}

// ---- Eval bar ------------------------------------------------------------

function EvalBar({ score = 0.4, height = 480, width = 14 }) {
  // score in pawn units; clamp to [-4,4] for display.
  const clamped = Math.max(-4, Math.min(4, score));
  const whitePct = (clamped + 4) / 8;
  return (
    <div style={{
      width, height,
      background: '#26241F',
      borderRadius: 4,
      overflow: 'hidden',
      position: 'relative',
      boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.04)'
    }}>
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        height: whitePct * 100 + '%',
        background: '#EFEAD8',
        transition: 'height 0.3s ease'
      }} />
      <div style={{
        position: 'absolute', left: 0, right: 0, top: '50%',
        height: 1, background: 'rgba(255,255,255,0.18)'
      }} />
    </div>);

}

// ---- Nav rail ------------------------------------------------------------

function NavRail({ active = 'dashboard' }) {
  const items = [
  { id: 'dashboard', label: 'Dashboard', icon: '◎' },
  { id: 'games', label: 'Games', icon: '□' },
  { id: 'lab', label: 'Mistake Lab', icon: '◇' },
  { id: 'drill', label: 'Drill', icon: '△' },
  { id: 'analysis', label: 'Analysis', icon: '◯' }];

  return (
    <aside style={{
      width: 220,
      borderRight: '1px solid ' + COLORS.line,
      padding: '24px 20px',
      display: 'flex', flexDirection: 'column', gap: 28,
      background: COLORS.bg,
      flexShrink: 0
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 22, height: 22, borderRadius: 5,
          background: 'linear-gradient(135deg, #EFEAD8 50%, #2A2620 50%)',
          boxShadow: '0 0 0 1px rgba(255,255,255,0.08)'
        }} />
        <div style={{ fontSize: 14, letterSpacing: '-0.01em', color: COLORS.text }}>
          Pattern <span style={{ fontFamily: '"Instrument Serif", serif', fontStyle: 'italic', fontWeight: 400 }}>Coach</span>
        </div>
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {items.map((it) =>
        <div key={it.id} style={{
          padding: '9px 10px',
          borderRadius: 6,
          display: 'flex', alignItems: 'center', gap: 12,
          background: active === it.id ? 'rgba(255,255,255,0.04)' : 'transparent',
          color: active === it.id ? COLORS.text : COLORS.textMute,
          fontSize: 13.5,
          letterSpacing: '-0.005em',
          cursor: 'default'
        }}>
            <span style={{ fontSize: 11, opacity: 0.55, width: 12, textAlign: 'center' }}>{it.icon}</span>
            <span>{it.label}</span>
          </div>
        )}
      </nav>

      <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{
          padding: '12px 12px',
          borderRadius: 8,
          background: COLORS.surface,
          border: '1px solid ' + COLORS.line
        }}>
          <div style={{ fontSize: 10.5, color: COLORS.textDim, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            Streak
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 4 }}>
            <div style={{ fontSize: 22, color: COLORS.text, letterSpacing: '-0.02em' }}>12</div>
            <div style={{ fontSize: 11, color: COLORS.textMute }}>days</div>
          </div>
          <div style={{ display: 'flex', gap: 3, marginTop: 8 }}>
            {Array.from({ length: 14 }).map((_, i) =>
            <div key={i} style={{
              flex: 1, height: 3, borderRadius: 1.5,
              background: i < 12 ? COLORS.idea : 'rgba(255,255,255,0.06)',
              opacity: i < 12 ? 0.7 : 1
            }} />
            )}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 4px' }}>
          <div style={{
            width: 26, height: 26, borderRadius: '50%',
            background: 'linear-gradient(140deg, #3a342a, #1a1714)',
            border: '1px solid ' + COLORS.lineStrong,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 11, color: COLORS.textMute,
            fontFamily: 'JetBrains Mono, monospace'
          }}>OM</div>
          <div style={{ fontSize: 12, color: COLORS.textMute }}>1640 · rapid</div>
        </div>
      </div>
    </aside>);

}

// ---- Top bar (page header) ----------------------------------------------

function TopBar({ title, eyebrow, right }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
      padding: '28px 36px 22px',
      borderBottom: '1px solid ' + COLORS.line
    }}>
      <div>
        {eyebrow &&
        <div style={{
          fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase',
          color: COLORS.textDim, marginBottom: 8,
          fontFamily: 'JetBrains Mono, monospace'
        }}>{eyebrow}</div>
        }
        <h1 style={{
          margin: 0, fontSize: 28, fontWeight: 400,
          letterSpacing: '-0.025em', color: COLORS.text
        }}>{title}</h1>
      </div>
      {right}
    </div>);

}

// ---- Move map node ------------------------------------------------------

function MoveMap({ you, them, idea, insight, compact = false }) {
  const Node = ({ label, move, color, dim }) =>
  <div style={{
    display: 'flex', flexDirection: 'column', gap: 6,
    opacity: dim ? 0.35 : 1,
    minWidth: 0
  }}>
      <div style={{
      fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase',
      color: COLORS.textDim, fontFamily: 'JetBrains Mono, monospace'
    }}>{label}</div>
      <div style={{
      display: 'flex', alignItems: 'center', gap: 8
    }}>
        <div style={{
        width: 6, height: 6, borderRadius: '50%', background: color,
        boxShadow: '0 0 0 4px ' + color + '22'
      }} />
        <div style={{
        fontSize: compact ? 18 : 22, color: COLORS.text,
        fontFamily: 'JetBrains Mono, monospace',
        letterSpacing: '-0.01em'
      }}>{move || '—'}</div>
      </div>
    </div>;


  return (
    <div style={{
      padding: '20px 22px',
      border: '1px solid ' + COLORS.line,
      borderRadius: 10,
      background: COLORS.surface
    }}>
      <div style={{
        fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase',
        color: COLORS.textDim, fontFamily: 'JetBrains Mono, monospace',
        marginBottom: 16
      }}>Move map</div>
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 16px 1fr 16px 1fr',
        alignItems: 'center', gap: 10
      }}>
        <Node label="You" move={you} color={COLORS.you} />
        <Arrow />
        <Node label="Them" move={them} color={COLORS.them} dim={!them} />
        <Arrow dim={!idea} />
        <Node label="Idea" move={idea} color={COLORS.idea} dim={!idea} />
      </div>
      {insight &&
      <div style={{
        marginTop: 16, paddingTop: 14, borderTop: '1px solid ' + COLORS.line,
        fontSize: 13, color: COLORS.textMute, letterSpacing: '-0.005em',
        lineHeight: 1.5
      }}>{insight}</div>
      }
    </div>);

}

function Arrow({ dim }) {
  return (
    <svg width="16" height="10" viewBox="0 0 16 10" style={{ opacity: dim ? 0.2 : 0.5 }}>
      <path d="M 0 5 L 13 5 M 9 1 L 13 5 L 9 9" stroke={COLORS.textMute} strokeWidth="1" fill="none" />
    </svg>);

}

// ---- Pill / Badge -------------------------------------------------------

function Pill({ children, tone = 'neutral', subtle = false }) {
  const toneMap = {
    you: COLORS.you, them: COLORS.them, idea: COLORS.idea, neutral: COLORS.textMute
  };
  const c = toneMap[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '3px 8px',
      borderRadius: 4,
      fontSize: 10.5,
      letterSpacing: '0.08em', textTransform: 'uppercase',
      fontFamily: 'JetBrains Mono, monospace',
      background: subtle ? 'transparent' : c + '14',
      color: c,
      border: subtle ? '1px solid ' + c + '40' : 'none'
    }}>{children}</span>);

}

// ---- Button -------------------------------------------------------------

function Btn({ children, primary, ghost, small, style, icon }) {
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    padding: small ? '7px 12px' : '11px 18px',
    fontSize: small ? 12 : 13,
    fontWeight: 500,
    letterSpacing: '-0.005em',
    borderRadius: 6,
    cursor: 'pointer',
    border: '1px solid ' + COLORS.line,
    background: COLORS.surface,
    color: COLORS.text,
    transition: 'all 0.15s'
  };
  if (primary) Object.assign(base, {
    background: COLORS.text,
    color: '#0c0c0d',
    border: '1px solid ' + COLORS.text
  });
  if (ghost) Object.assign(base, {
    background: 'transparent',
    border: '1px solid transparent',
    color: COLORS.textMute
  });
  return (
    <button style={{ ...base, ...(style || {}) }}>
      {icon && <span style={{ fontSize: 11, opacity: 0.7 }}>{icon}</span>}
      {children}
    </button>);

}

// ---- Screen frame (the inside of an artboard) ---------------------------

function ScreenFrame({ children, nav = 'dashboard' }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      display: 'flex',
      background: COLORS.bg,
      color: COLORS.text,
      fontFamily: '"Hanken Grotesk", system-ui, sans-serif',
      fontSize: 14,
      letterSpacing: '-0.005em'
    }}>
      <NavRail active={nav} />
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {children}
      </main>
    </div>);

}

Object.assign(window, {
  PC_COLORS: COLORS,
  Board, EvalBar, NavRail, TopBar, MoveMap, Pill, Btn, ScreenFrame, Arrow,
  BoardSettingsContext, BOARD_THEMES
});
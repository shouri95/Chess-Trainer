// Mistake Lab — list + detail (board-first split view).

const { PC_COLORS: MC, Board: MBoard, TopBar: MTopBar, Btn: MBtn, Pill: MPill, MoveMap: MMoveMap, ScreenFrame: MFrame } = window;

function MistakeLabScreen() {
  const items = [
    { phase: 'OPN', ply: '14.', san: 'Bc4', q: 'blunder', title: 'Reply ignored', consequence: 'Nxh5 wins the queen', selected: true },
    { phase: 'OPN', ply: '11.', san: 'Qh4', q: 'blunder', title: 'Queen out too early', consequence: 'g3 traps and wins' },
    { phase: 'MID', ply: '17.', san: 'Nxe5', q: 'blunder', title: 'Loose piece left', consequence: 'Qxe5 hangs the knight' },
    { phase: 'MID', ply: '22.', san: 'f3?', q: 'inacc',   title: 'King shelter weakened', consequence: 'Allows Qh4 attack' },
    { phase: 'END', ply: '34.', san: 'Kf2', q: 'inacc',   title: 'Passive endgame king', consequence: 'Loses a tempo to the pawn race' },
    { phase: 'OPN', ply: '08.', san: 'Bd3', q: 'inacc',   title: 'Opening tempo leaking', consequence: 'Bc4 was the natural square' },
    { phase: 'MID', ply: '19.', san: 'Re1', q: 'miss',    title: 'Missed forcing move', consequence: 'Nxf7! was winning' },
    { phase: 'OPN', ply: '12.', san: 'h6',  q: 'inacc',   title: 'Pawn move, no purpose', consequence: 'Castling first was simpler' },
  ];

  // Position: white just played Qh5? hanging to Nxh5 (knight on f6).
  const fen = 'r1bqk2r/pppp1ppp/2n2n2/2b1p2Q/2B1P3/5N2/PPPP1PPP/RNB1K2R';

  return (
    <MFrame nav="lab">
      <MTopBar
        eyebrow="14 spots · 4 patterns"
        title="Mistake Lab"
        right={
          <div style={{ display: 'flex', gap: 8 }}>
            <FilterPill label="All phases" />
            <FilterPill label="All patterns" />
            <FilterPill label="Last 30 days" active />
          </div>
        }
      />
      <div style={{
        flex: 1, display: 'grid',
        gridTemplateColumns: '380px 1fr',
        minHeight: 0,
      }}>
        {/* List */}
        <div style={{
          borderRight: '1px solid ' + MC.line,
          overflow: 'auto', display: 'flex', flexDirection: 'column',
        }}>
          <PatternHeader />
          {items.map((it, i) => <MistakeRow key={i} {...it} />)}
        </div>
        {/* Detail */}
        <MistakeDetail fen={fen} />
      </div>
    </MFrame>
  );
}

function FilterPill({ label, active }) {
  return (
    <div style={{
      padding: '7px 12px', borderRadius: 6,
      border: '1px solid ' + (active ? 'rgba(255,255,255,0.18)' : MC.line),
      background: active ? 'rgba(255,255,255,0.04)' : 'transparent',
      fontSize: 12,
      color: active ? MC.text : MC.textMute,
      display: 'flex', alignItems: 'center', gap: 6,
    }}>
      {label}
      <span style={{ fontSize: 8, opacity: 0.5 }}>▾</span>
    </div>
  );
}

function PatternHeader() {
  return (
    <div style={{
      padding: '16px 28px',
      borderBottom: '1px solid ' + MC.line,
      display: 'flex', flexDirection: 'column', gap: 10,
    }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{
            width: 6, height: 6, borderRadius: '50%', background: MC.you,
            boxShadow: '0 0 6px ' + MC.you,
          }} />
          <span style={{ fontSize: 13.5, color: MC.text, letterSpacing: '-0.005em' }}>
            Reply ignored
          </span>
        </div>
        <span style={{
          fontSize: 11, color: MC.textMute,
          fontFamily: 'JetBrains Mono, monospace',
        }}>14 · 4 patterns</span>
      </div>
      <div style={{
        display: 'flex', gap: 2, height: 4,
      }}>
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} style={{
            flex: [6, 4, 3, 1][i], background: [MC.you, MC.them, MC.idea, MC.neutral][i],
            opacity: 0.6, borderRadius: 1,
          }} />
        ))}
      </div>
    </div>
  );
}

function MistakeRow({ phase, ply, san, q, title, consequence, selected }) {
  const qColor = q === 'blunder' ? MC.them : q === 'inacc' ? MC.you : MC.idea;
  return (
    <div style={{
      padding: '14px 28px',
      display: 'grid',
      gridTemplateColumns: '30px 1fr',
      gap: 14, alignItems: 'flex-start',
      borderBottom: '1px solid ' + MC.line,
      background: selected ? 'rgba(255,255,255,0.025)' : 'transparent',
      borderLeft: selected ? '2px solid ' + MC.you : '2px solid transparent',
    }}>
      <div style={{
        fontSize: 9.5, color: MC.textDim, letterSpacing: '0.12em',
        fontFamily: 'JetBrains Mono, monospace',
      }}>{phase}</div>
      <div>
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <span style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 11, color: MC.textDim,
            }}>{ply}</span>
            <span style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 14.5, color: MC.text, letterSpacing: '-0.005em',
            }}>{san}</span>
            <span style={{
              width: 5, height: 5, borderRadius: '50%', background: qColor,
            }} />
          </div>
          <span style={{
            fontSize: 10.5, color: MC.textDim, letterSpacing: '0.06em',
            fontFamily: 'JetBrains Mono, monospace',
          }}>{title.toUpperCase()}</span>
        </div>
        <div style={{
          fontSize: 12, color: MC.textMute, marginTop: 6,
          letterSpacing: '-0.003em',
        }}>{consequence}</div>
      </div>
    </div>
  );
}

function MistakeDetail({ fen }) {
  const [view, setView] = React.useState('idea');
  // View = your move / idea / consequence
  // Each view alters highlights/arrows on the board.

  const views = {
    your: {
      highlights: { c4: 'you', f1: 'you' },
      arrows: [{ from: 'f1', to: 'c4', kind: 'you' }],
      label: 'Your move',
    },
    them: {
      highlights: { h5: 'them', f6: 'them' },
      arrows: [{ from: 'f6', to: 'h5', kind: 'them' }],
      label: 'Their reply',
    },
    idea: {
      highlights: { f3: 'idea', g1: 'idea' },
      arrows: [{ from: 'g1', to: 'f3', kind: 'idea' }],
      label: 'Idea',
    },
  };
  const v = views[view];

  return (
    <div style={{
      padding: '28px 36px',
      display: 'grid',
      gridTemplateColumns: '420px 1fr',
      gap: 36, overflow: 'auto',
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <MBoard
          fen={fen}
          size={420}
          highlights={v.highlights}
          arrows={v.arrows}
        />
        <Segmented
          options={[
            { id: 'your', label: 'Your move', color: MC.you },
            { id: 'them', label: 'Their reply', color: MC.them },
            { id: 'idea', label: 'Idea', color: MC.idea },
          ]}
          value={view}
          onChange={setView}
        />
      </div>

      <div style={{
        display: 'flex', flexDirection: 'column', gap: 22, minWidth: 0,
      }}>
        <div>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12,
          }}>
            <MPill tone="them">Blunder</MPill>
            <MPill tone="you" subtle>Reply ignored</MPill>
            <span style={{
              fontSize: 11, color: MC.textMute,
              fontFamily: 'JetBrains Mono, monospace',
              marginLeft: 'auto',
            }}>14. Bc4  ·  vs NightForge_99</span>
          </div>
          <h2 style={{
            margin: 0, fontSize: 30, fontWeight: 400,
            letterSpacing: '-0.025em', lineHeight: 1.1,
            color: MC.text,
          }}>
            You moved <span style={{
              fontFamily: 'JetBrains Mono, monospace',
              color: MC.you,
            }}>Bc4</span> without seeing
            <span style={{
              fontFamily: '"Instrument Serif", serif', fontStyle: 'italic', fontWeight: 400,
            }}> Black's </span>
            <span style={{
              fontFamily: 'JetBrains Mono, monospace',
              color: MC.them,
            }}>Nxh5</span>.
          </h2>
        </div>

        <MMoveMap
          you="Bc4"
          them="Nxh5"
          idea="Nf3"
          insight="The knight on f6 was already eyeing h5. Defend the queen before placing the bishop."
        />

        <div style={{ display: 'flex', gap: 10 }}>
          <MBtn primary icon="▶">Train this position</MBtn>
          <MBtn>Open in Analysis</MBtn>
          <MBtn ghost>Skip</MBtn>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <MBtn small icon="←" />
            <MBtn small icon="→" />
          </div>
        </div>

        <Drawer title="Engine lines" hint="depth 22 · stockfish 16">
          <EngineLine pv="14. Nc3 d6 15. h3 a6 16. a4" score="+0.4" />
          <EngineLine pv="14. h3 d6 15. Nc3 a6 16. a4 Ba7" score="+0.3" dim />
          <EngineLine pv="14. Bc4?? Nxh5 15. gxh5 Qxh5" score="-3.4" warn />
        </Drawer>
      </div>
    </div>
  );
}

function Segmented({ options, value, onChange }) {
  return (
    <div style={{
      display: 'flex', padding: 3,
      borderRadius: 8,
      border: '1px solid ' + MC.line,
      background: MC.surface,
    }}>
      {options.map(o => {
        const active = o.id === value;
        return (
          <div key={o.id}
            onClick={() => onChange(o.id)}
            style={{
              flex: 1,
              padding: '8px 12px',
              borderRadius: 5,
              background: active ? 'rgba(255,255,255,0.06)' : 'transparent',
              fontSize: 12.5,
              color: active ? MC.text : MC.textMute,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              cursor: 'pointer',
              fontWeight: active ? 500 : 400,
            }}>
            <span style={{
              width: 6, height: 6, borderRadius: '50%', background: o.color,
              boxShadow: active ? '0 0 6px ' + o.color : 'none',
              opacity: active ? 1 : 0.5,
            }} />
            {o.label}
          </div>
        );
      })}
    </div>
  );
}

function Drawer({ title, hint, children }) {
  return (
    <div style={{
      border: '1px solid ' + MC.line,
      borderRadius: 10,
      background: MC.surface,
      overflow: 'hidden',
    }}>
      <div style={{
        padding: '12px 18px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        borderBottom: '1px solid ' + MC.line,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 10, color: MC.textDim }}>▾</span>
          <div style={{
            fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
            color: MC.textMute, fontFamily: 'JetBrains Mono, monospace',
          }}>{title}</div>
        </div>
        <div style={{
          fontSize: 10.5, color: MC.textDim,
          fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.06em',
        }}>{hint}</div>
      </div>
      <div>{children}</div>
    </div>
  );
}

function EngineLine({ pv, score, dim, warn }) {
  return (
    <div style={{
      padding: '10px 18px',
      borderBottom: '1px solid ' + MC.line,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      opacity: dim ? 0.55 : 1,
    }}>
      <div style={{
        fontSize: 12, color: warn ? MC.them : MC.textMute,
        fontFamily: 'JetBrains Mono, monospace',
        letterSpacing: '-0.005em',
      }}>{pv}</div>
      <div style={{
        fontSize: 12, color: warn ? MC.them : MC.text,
        fontFamily: 'JetBrains Mono, monospace',
      }}>{score}</div>
    </div>
  );
}

window.MistakeLabScreen = MistakeLabScreen;

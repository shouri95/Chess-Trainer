// Dashboard — main weakness hero.
// Visual command surface: one weakness, one cue, one action.

const { PC_COLORS: C, NavRail, TopBar, Btn, Pill, ScreenFrame, Arrow: HArrow } = window;

function DashboardScreen() {
  return (
    <ScreenFrame nav="dashboard">
      <TopBar
        eyebrow="Tuesday · May 20"
        title="Good morning, Ola."
        right={
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '7px 10px', border: '1px solid ' + C.line, borderRadius: 6,
              fontSize: 12, color: C.textMute,
              fontFamily: 'JetBrains Mono, monospace',
            }}>
              <span style={{ color: C.idea }}>●</span>
              <span>74 games · synced 3m ago</span>
            </div>
            <Btn ghost icon="↗">Import</Btn>
          </div>
        }
      />

      <div style={{
        flex: 1, padding: '32px 36px',
        display: 'grid',
        gridTemplateColumns: '1.4fr 1fr',
        gap: 28,
        minHeight: 0,
      }}>
        {/* Hero weakness card */}
        <section style={{
          padding: '28px 32px 32px',
          borderRadius: 14,
          background: 'radial-gradient(ellipse at 30% 0%, #1d1a14 0%, #131311 55%, #0e0e0d 100%)',
          border: '1px solid ' + C.line,
          display: 'flex', flexDirection: 'column',
          position: 'relative',
          overflow: 'hidden',
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <Pill tone="you">Main weakness</Pill>
            <div style={{
              fontSize: 11, color: C.textMute,
              fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.08em',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{
                display: 'inline-block', width: 6, height: 6, borderRadius: '50%',
                background: C.neutral,
              }} />
              STABLE · 3 WEEKS
            </div>
          </div>

          <ReplyOrbit />

          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 0,
            borderTop: '1px solid ' + C.line,
            marginTop: 28, paddingTop: 22,
          }}>
            <Metric label="Spots" value="14" hint="due now" />
            <Metric label="Review" value="4" unit="min" divider />
            <Metric label="Clean" value="33" unit="%" divider trend="-6" />
          </div>

          <div style={{
            display: 'flex', gap: 10, marginTop: 26,
          }}>
            <Btn primary style={{ flex: 1, padding: '13px 18px', fontSize: 13.5 }}>
              Train this pattern
              <span style={{
                marginLeft: 4, fontSize: 11, opacity: 0.5,
                fontFamily: 'JetBrains Mono, monospace',
              }}>→</span>
            </Btn>
            <Btn style={{ flex: 1, padding: '13px 18px', fontSize: 13.5 }}>Review evidence</Btn>
          </div>
        </section>

        {/* Right column */}
        <section style={{ display: 'flex', flexDirection: 'column', gap: 22, minHeight: 0 }}>
          <ExamplesCard />
          <TodayCard />
        </section>
      </div>
    </ScreenFrame>
  );
}

function Metric({ label, value, unit, hint, trend, divider }) {
  return (
    <div style={{
      paddingLeft: divider ? 22 : 0,
      borderLeft: divider ? '1px solid ' + C.line : 'none',
    }}>
      <div style={{
        fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
        color: C.textDim, fontFamily: 'JetBrains Mono, monospace',
      }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 8 }}>
        <div style={{
          fontSize: 34, color: C.text, letterSpacing: '-0.03em',
          fontWeight: 300,
        }}>{value}</div>
        {unit && <div style={{ fontSize: 13, color: C.textMute }}>{unit}</div>}
      </div>
      <div style={{ fontSize: 11, color: C.textMute, marginTop: 4 }}>
        {hint || (trend && <span style={{ color: C.them }}>{trend} pts</span>)}
      </div>
    </div>
  );
}

// The hero visualization: three nodes (You / Them / Idea) on an orbit, with
// the You node holding the central cue.
function ReplyOrbit() {
  return (
    <div style={{
      position: 'relative', flex: 1,
      minHeight: 320,
      marginTop: 14,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      {/* central title block */}
      <div style={{
        position: 'absolute', left: '50%', top: '50%',
        transform: 'translate(-50%, -50%)',
        textAlign: 'center', zIndex: 3, maxWidth: 340,
      }}>
        <div style={{
          fontSize: 32, lineHeight: 1.1,
          letterSpacing: '-0.03em',
          color: C.text,
        }}>
          You move <span style={{
            fontFamily: '"Instrument Serif", serif', fontStyle: 'italic',
            fontWeight: 400, color: C.you,
          }}>before</span> seeing the reply.
        </div>
        <div style={{
          marginTop: 14, fontSize: 12.5, color: C.textMute,
          fontFamily: 'JetBrains Mono, monospace',
          letterSpacing: '0.06em', textTransform: 'uppercase',
        }}>
          Opponent replies ignored · 100 spots
        </div>
      </div>

      {/* arcs / rings */}
      <svg viewBox="0 0 600 320" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        <defs>
          <radialGradient id="ring-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.04" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>
        <ellipse cx="300" cy="160" rx="270" ry="135" fill="none"
          stroke="rgba(255,255,255,0.07)" strokeDasharray="2 5" />
        <ellipse cx="300" cy="160" rx="200" ry="100" fill="none"
          stroke="rgba(255,255,255,0.05)" strokeDasharray="2 5" />
        <ellipse cx="300" cy="160" rx="270" ry="135" fill="url(#ring-glow)" />

        {/* You arrow to Them */}
        <path d="M 110 90 Q 220 70 300 90"
          stroke={C.you} strokeOpacity="0.55" strokeWidth="1.2" fill="none" strokeDasharray="3 3" />
        {/* Them to Idea */}
        <path d="M 500 90 Q 510 220 380 250"
          stroke={C.them} strokeOpacity="0.55" strokeWidth="1.2" fill="none" strokeDasharray="3 3" />
        {/* Idea back to You */}
        <path d="M 220 250 Q 80 200 110 90"
          stroke={C.idea} strokeOpacity="0.45" strokeWidth="1.2" fill="none" strokeDasharray="3 3" />
      </svg>

      {/* You node */}
      <OrbitNode style={{ left: '14%', top: '14%' }}
        kind="you" label="You" move="Bc4" hint="developed bishop" />
      <OrbitNode style={{ right: '14%', top: '14%' }}
        kind="them" label="Them" move="Nxh5" hint="wins the queen" />
      <OrbitNode style={{ left: '34%', bottom: '6%' }}
        kind="idea" label="Idea" move="Nf3" hint="defends, develops" />
    </div>
  );
}

function OrbitNode({ kind, label, move, hint, style }) {
  const color =
    kind === 'you' ? C.you : kind === 'them' ? C.them : C.idea;
  return (
    <div style={{
      position: 'absolute',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
      zIndex: 2,
      ...style,
    }}>
      <div style={{
        padding: '8px 14px',
        background: '#0e0e0d',
        border: '1px solid ' + color + '60',
        borderRadius: 999,
        display: 'flex', alignItems: 'center', gap: 10,
        boxShadow: '0 0 0 6px ' + color + '08, 0 8px 20px -8px rgba(0,0,0,0.6)',
      }}>
        <span style={{
          width: 6, height: 6, borderRadius: '50%', background: color,
          boxShadow: '0 0 8px ' + color,
        }} />
        <span style={{
          fontSize: 10.5, color: C.textMute,
          fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.12em',
          textTransform: 'uppercase',
        }}>{label}</span>
        <span style={{
          fontSize: 14, color: C.text,
          fontFamily: 'JetBrains Mono, monospace',
          letterSpacing: '-0.01em',
        }}>{move}</span>
      </div>
      <div style={{ fontSize: 11, color: C.textDim }}>{hint}</div>
    </div>
  );
}

function ExamplesCard() {
  const ex = [
    { game: 'vs. NightForge', san: 'Bc4',  ply: '14.', loss: '-3.4' },
    { game: 'vs. otto77',     san: 'Qh4',  ply: '11.', loss: '-2.8' },
    { game: 'vs. larsa',      san: 'Nxe5', ply: '17.', loss: '-2.1' },
  ];
  return (
    <div style={{
      padding: 22,
      border: '1px solid ' + C.line, borderRadius: 12,
      background: C.surface,
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 16,
      }}>
        <div>
          <div style={{
            fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
            color: C.textDim, fontFamily: 'JetBrains Mono, monospace',
          }}>Top examples</div>
          <div style={{ fontSize: 15, color: C.text, marginTop: 4, letterSpacing: '-0.01em' }}>
            Where this pattern shows up
          </div>
        </div>
        <span style={{ fontSize: 11, color: C.textMute, fontFamily: 'JetBrains Mono, monospace' }}>3 of 14</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {ex.map((e, i) => (
          <div key={i} style={{
            display: 'grid',
            gridTemplateColumns: '36px 1fr auto auto',
            alignItems: 'center', gap: 14,
            padding: '12px 0',
            borderTop: i === 0 ? 'none' : '1px solid ' + C.line,
          }}>
            <div style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 11, color: C.textDim, letterSpacing: '0.04em',
            }}>{e.ply}</div>
            <div>
              <div style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 15, color: C.text,
              }}>{e.san}</div>
              <div style={{ fontSize: 11.5, color: C.textMute, marginTop: 2 }}>{e.game}</div>
            </div>
            <div style={{
              fontSize: 11.5, color: C.them,
              fontFamily: 'JetBrains Mono, monospace',
            }}>{e.loss}</div>
            <HArrow />
          </div>
        ))}
      </div>
    </div>
  );
}

function TodayCard() {
  return (
    <div style={{
      padding: 22,
      border: '1px solid ' + C.line, borderRadius: 12,
      background: C.surface,
      display: 'flex', flexDirection: 'column', gap: 16,
    }}>
      <div style={{
        fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
        color: C.textDim, fontFamily: 'JetBrains Mono, monospace',
      }}>This week</div>

      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 70 }}>
        {[18, 24, 12, 32, 28, 40, 16].map((v, i) => (
          <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
            <div style={{
              width: '100%',
              height: v + 'px',
              background: i === 6 ? C.you : 'rgba(255,255,255,0.10)',
              borderRadius: 2,
            }} />
            <div style={{
              fontSize: 9.5, color: i === 6 ? C.text : C.textDim,
              fontFamily: 'JetBrains Mono, monospace',
              letterSpacing: '0.08em',
            }}>{['M','T','W','T','F','S','S'][i]}</div>
          </div>
        ))}
      </div>

      <div style={{
        display: 'flex', justifyContent: 'space-between',
        paddingTop: 12, borderTop: '1px solid ' + C.line,
      }}>
        <div>
          <div style={{ fontSize: 11, color: C.textMute }}>Resolved</div>
          <div style={{
            fontSize: 18, color: C.text, marginTop: 2, letterSpacing: '-0.02em',
          }}>22 / 36</div>
        </div>
        <div>
          <div style={{ fontSize: 11, color: C.textMute }}>Patterns</div>
          <div style={{
            fontSize: 18, color: C.text, marginTop: 2, letterSpacing: '-0.02em',
          }}>4 active</div>
        </div>
        <div>
          <div style={{ fontSize: 11, color: C.textMute }}>Best run</div>
          <div style={{
            fontSize: 18, color: C.idea, marginTop: 2, letterSpacing: '-0.02em',
            fontFamily: 'JetBrains Mono, monospace',
          }}>+7</div>
        </div>
      </div>
    </div>
  );
}

window.DashboardScreen = DashboardScreen;

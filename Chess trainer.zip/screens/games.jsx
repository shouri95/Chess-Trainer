// Games — replay imported games. Calm list + replay panel.

const { PC_COLORS: GC, Board: GBoard, TopBar: GTopBar, Btn: GBtn, Pill: GPill, ScreenFrame: GFrame } = window;

function GamesScreen() {
  const games = [
    { opp: 'NightForge_99', result: 'L',  ply: 42, tc: '10+0', opening: 'Italian, Two Knights', date: 'Today', mistakes: 3, selected: true },
    { opp: 'otto77',        result: 'W',  ply: 51, tc: '15+10', opening: "Queen's Gambit Decl.", date: 'Today', mistakes: 1 },
    { opp: 'larsa',         result: 'L',  ply: 38, tc: '10+0', opening: 'Caro-Kann, Advance', date: 'Yesterday', mistakes: 2 },
    { opp: 'm_g_b',         result: 'D',  ply: 64, tc: '15+10', opening: 'Ruy Lopez, Berlin', date: 'Yesterday', mistakes: 0 },
    { opp: 'kasparov_fan',  result: 'W',  ply: 29, tc: '10+0', opening: 'Scotch Game', date: 'May 18', mistakes: 1 },
    { opp: 'pearlsnap',     result: 'L',  ply: 47, tc: '10+0', opening: 'Sicilian, Najdorf', date: 'May 18', mistakes: 4 },
    { opp: 'sundae',        result: 'W',  ply: 33, tc: '15+10', opening: 'London System', date: 'May 17', mistakes: 1 },
    { opp: 'tact_tigress',  result: 'L',  ply: 22, tc: '10+0', opening: "King's Indian Att.", date: 'May 17', mistakes: 2 },
  ];

  // A mid-game position (after Italian moves) for the replay board.
  const fen = 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R';

  return (
    <GFrame nav="games">
      <GTopBar
        eyebrow="74 games · last 30 days"
        title="Games"
        right={
          <div style={{ display: 'flex', gap: 8 }}>
            <FilterChip label="All time controls" />
            <FilterChip label="Both colors" />
            <FilterChip label="With mistakes" active />
            <GBtn ghost small icon="⋯" />
          </div>
        }
      />

      <div style={{
        flex: 1, display: 'grid',
        gridTemplateColumns: '440px 1fr',
        minHeight: 0,
      }}>
        {/* list */}
        <div style={{
          borderRight: '1px solid ' + GC.line,
          overflow: 'hidden', display: 'flex', flexDirection: 'column',
        }}>
          <div style={{
            padding: '14px 28px 10px',
            display: 'grid',
            gridTemplateColumns: '24px 1fr 60px 30px',
            gap: 12, alignItems: 'center',
            fontSize: 10.5, letterSpacing: '0.14em', textTransform: 'uppercase',
            color: GC.textDim, fontFamily: 'JetBrains Mono, monospace',
          }}>
            <div></div>
            <div>Opponent / Opening</div>
            <div>Plies</div>
            <div style={{ textAlign: 'right' }}>!</div>
          </div>
          <div style={{ flex: 1, overflow: 'auto' }}>
            {games.map((g, i) => (
              <GameRow key={i} {...g} />
            ))}
          </div>
        </div>

        {/* replay */}
        <div style={{
          padding: '28px 36px',
          display: 'grid',
          gridTemplateColumns: '380px 1fr',
          gap: 32,
          minWidth: 0,
        }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <GBoard
              fen={fen}
              size={380}
              lastMove={{ from: 'f1', to: 'c4' }}
              highlights={{ c4: 'you' }}
            />
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10,
            }}>
              <ReplayBtn icon="⏪" />
              <ReplayBtn icon="◀" />
              <div style={{
                flex: 1, height: 4, background: 'rgba(255,255,255,0.08)',
                borderRadius: 2, position: 'relative',
              }}>
                <div style={{
                  position: 'absolute', left: 0, top: 0, bottom: 0,
                  width: '38%', background: GC.text, borderRadius: 2,
                }} />
              </div>
              <ReplayBtn icon="▶" />
              <ReplayBtn icon="⏩" />
            </div>
            <div style={{
              fontSize: 11, color: GC.textMute,
              fontFamily: 'JetBrains Mono, monospace',
              textAlign: 'center', letterSpacing: '0.06em',
            }}>
              MOVE 9 / 24  ·  WHITE TO MOVE
            </div>
          </div>

          {/* move strip */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18, minWidth: 0 }}>
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              paddingBottom: 14, borderBottom: '1px solid ' + GC.line,
            }}>
              <div>
                <div style={{ fontSize: 16, color: GC.text, letterSpacing: '-0.01em' }}>
                  Pattern_Coach <span style={{ color: GC.textDim, margin: '0 8px' }}>vs</span> NightForge_99
                </div>
                <div style={{ fontSize: 12, color: GC.textMute, marginTop: 4 }}>
                  Italian Game, Two Knights  ·  10+0  ·  Today · 4:12pm
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <GBtn small icon="⤳">Mistake Lab</GBtn>
                <GBtn small icon="⤴">Analysis</GBtn>
              </div>
            </div>

            <MoveLog />
          </div>
        </div>
      </div>
    </GFrame>
  );
}

function FilterChip({ label, active }) {
  return (
    <div style={{
      padding: '7px 12px',
      borderRadius: 6,
      border: '1px solid ' + (active ? 'rgba(255,255,255,0.18)' : GC.line),
      background: active ? 'rgba(255,255,255,0.04)' : 'transparent',
      fontSize: 12,
      color: active ? GC.text : GC.textMute,
      display: 'flex', alignItems: 'center', gap: 6,
    }}>
      {label}
      <span style={{ fontSize: 8, opacity: 0.5 }}>▾</span>
    </div>
  );
}

function ReplayBtn({ icon }) {
  return (
    <div style={{
      width: 30, height: 30,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      borderRadius: 6,
      border: '1px solid ' + GC.line,
      color: GC.textMute, fontSize: 10,
    }}>{icon}</div>
  );
}

function GameRow({ opp, result, ply, tc, opening, date, mistakes, selected }) {
  const resultColor =
    result === 'W' ? GC.idea : result === 'L' ? GC.them : GC.textMute;
  return (
    <div style={{
      padding: '14px 28px',
      display: 'grid',
      gridTemplateColumns: '24px 1fr 60px 30px',
      gap: 12, alignItems: 'center',
      borderBottom: '1px solid ' + GC.line,
      background: selected ? 'rgba(255,255,255,0.025)' : 'transparent',
      borderLeft: selected ? '2px solid ' + GC.text : '2px solid transparent',
    }}>
      <div style={{
        width: 18, height: 18, borderRadius: 4,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: resultColor + '18',
        color: resultColor,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, fontWeight: 600,
      }}>{result}</div>
      <div style={{ minWidth: 0 }}>
        <div style={{
          fontSize: 13.5, color: GC.text, letterSpacing: '-0.005em',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>{opp}</div>
        <div style={{
          fontSize: 11.5, color: GC.textMute, marginTop: 2,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>{opening} · {tc} · {date}</div>
      </div>
      <div style={{
        fontSize: 11, color: GC.textDim,
        fontFamily: 'JetBrains Mono, monospace',
      }}>{ply}</div>
      <div style={{ textAlign: 'right' }}>
        {mistakes > 0 ? (
          <span style={{
            display: 'inline-block', minWidth: 18, padding: '2px 5px',
            borderRadius: 3, background: GC.them + '22', color: GC.them,
            fontSize: 10, fontFamily: 'JetBrains Mono, monospace',
            textAlign: 'center',
          }}>{mistakes}</span>
        ) : (
          <span style={{ color: GC.textDim, fontSize: 11 }}>—</span>
        )}
      </div>
    </div>
  );
}

function MoveLog() {
  // Pairs of (white, black) moves with optional quality markers
  const moves = [
    { w: { san: 'e4' },               b: { san: 'e5' } },
    { w: { san: 'Nf3' },              b: { san: 'Nc6' } },
    { w: { san: 'Bc4', q: 'good' },   b: { san: 'Nf6' } },
    { w: { san: 'd3' },               b: { san: 'Bc5' } },
    { w: { san: 'O-O' },              b: { san: 'O-O' } },
    { w: { san: 'h3' },               b: { san: 'd6' } },
    { w: { san: 'Bb3', q: 'inacc' },  b: { san: 'h6' } },
    { w: { san: 'Re1' },              b: { san: 'Be6' } },
    { w: { san: 'Bc4', q: 'blunder', active: true } },
  ];
  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      border: '1px solid ' + GC.line, borderRadius: 10,
      overflow: 'hidden',
    }}>
      <div style={{
        padding: '12px 18px',
        borderBottom: '1px solid ' + GC.line,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div style={{
          fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
          color: GC.textDim, fontFamily: 'JetBrains Mono, monospace',
        }}>Move log</div>
        <div style={{ display: 'flex', gap: 14, fontSize: 11, color: GC.textMute }}>
          <Legend color={GC.idea} label="Good" />
          <Legend color={GC.you} label="Inaccuracy" />
          <Legend color={GC.them} label="Blunder" />
        </div>
      </div>
      <div style={{ padding: '6px 4px', overflow: 'auto' }}>
        {moves.map((m, i) => (
          <div key={i} style={{
            display: 'grid',
            gridTemplateColumns: '40px 1fr 1fr',
            padding: '6px 14px',
            background: m.w?.active || m.b?.active ? 'rgba(226,96,74,0.05)' : 'transparent',
            borderRadius: 4,
          }}>
            <div style={{
              fontSize: 11, color: GC.textDim,
              fontFamily: 'JetBrains Mono, monospace',
            }}>{i + 1}.</div>
            <MoveCell move={m.w} />
            <MoveCell move={m.b} />
          </div>
        ))}
      </div>
    </div>
  );
}

function MoveCell({ move }) {
  if (!move) return <div />;
  const q = move.q;
  const dotColor =
    q === 'good' ? GC.idea : q === 'inacc' ? GC.you : q === 'blunder' ? GC.them : null;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: 13,
      color: move.active ? GC.text : GC.textMute,
      fontWeight: move.active ? 500 : 400,
    }}>
      <span>{move.san}</span>
      {dotColor && (
        <span style={{
          width: 6, height: 6, borderRadius: '50%', background: dotColor,
        }} />
      )}
    </div>
  );
}

function Legend({ color, label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: color }} />
      <span>{label}</span>
    </div>
  );
}

window.GamesScreen = GamesScreen;

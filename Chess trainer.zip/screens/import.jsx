// Import — first-run / connect Chess.com. Practical, trustworthy, board-adjacent.

const { PC_COLORS: IC, Board: IBoard, Btn: IBtn, Pill: IPill } = window;

function ImportScreen() {
  return (
    <div style={{
      width: '100%', height: '100%',
      background: IC.bg,
      color: IC.text,
      fontFamily: '"Hanken Grotesk", system-ui, sans-serif',
      display: 'grid',
      gridTemplateColumns: '1.05fr 1fr',
      minHeight: 0,
    }}>
      {/* Left: import form */}
      <div style={{
        padding: '64px 72px',
        display: 'flex', flexDirection: 'column',
        gap: 36, minHeight: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 28, height: 28, borderRadius: 6,
            background: 'linear-gradient(135deg, #EFEAD8 50%, #2A2620 50%)',
            boxShadow: '0 0 0 1px rgba(255,255,255,0.08)',
          }} />
          <div style={{ fontSize: 16, letterSpacing: '-0.01em' }}>
            Pattern <span style={{
              fontFamily: '"Instrument Serif", serif', fontStyle: 'italic',
            }}>Coach</span>
          </div>
        </div>

        <div>
          <div style={{
            fontSize: 10.5, letterSpacing: '0.18em', textTransform: 'uppercase',
            color: IC.textDim, fontFamily: 'JetBrains Mono, monospace',
            marginBottom: 18,
          }}>Connect</div>
          <h1 style={{
            margin: 0, fontSize: 44, fontWeight: 400,
            letterSpacing: '-0.03em', lineHeight: 1.05,
            color: IC.text,
            maxWidth: 480,
          }}>
            Bring in <span style={{
              fontFamily: '"Instrument Serif", serif', fontStyle: 'italic',
              color: IC.you,
            }}>your games.</span> We'll find the shapes
            you keep <span style={{
              fontFamily: '"Instrument Serif", serif', fontStyle: 'italic',
              color: IC.them,
            }}>misreading.</span>
          </h1>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, maxWidth: 480 }}>
          <FormRow label="Chess.com username" mono>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{
                fontSize: 13, color: IC.text,
                fontFamily: 'JetBrains Mono, monospace',
              }}>magrios</span>
              <span style={{
                width: 6, height: 6, borderRadius: '50%', background: IC.idea,
                boxShadow: '0 0 6px ' + IC.idea,
              }} />
            </div>
          </FormRow>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <FormRow label="Range">
              <div style={{ fontSize: 13, color: IC.text }}>Last 3 months</div>
            </FormRow>
            <FormRow label="Cap">
              <div style={{ fontSize: 13, color: IC.text }}>200 games</div>
            </FormRow>
          </div>

          <FormRow label="Time controls">
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {['Bullet', 'Blitz', 'Rapid', 'Daily'].map((t, i) => (
                <span key={t} style={{
                  padding: '3px 9px',
                  borderRadius: 4,
                  background: i === 2 ? IC.text : 'transparent',
                  color: i === 2 ? '#0c0c0d' : IC.textMute,
                  border: '1px solid ' + (i === 2 ? IC.text : IC.line),
                  fontSize: 11.5,
                  fontFamily: 'JetBrains Mono, monospace',
                }}>{t}</span>
              ))}
            </div>
          </FormRow>
        </div>

        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          paddingTop: 8,
        }}>
          <IBtn primary style={{ padding: '13px 22px', fontSize: 14 }} icon="↗">
            Sync 74 games
          </IBtn>
          <IBtn>Paste PGN</IBtn>
          <IBtn ghost>Try sample</IBtn>
        </div>

        <div style={{
          marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 18,
          fontSize: 11, color: IC.textDim,
          fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.04em',
        }}>
          <span>LOCAL ANALYSIS</span>
          <span>·</span>
          <span>NO ACCOUNT REQUIRED</span>
          <span>·</span>
          <span>STOCKFISH 16</span>
        </div>
      </div>

      {/* Right: live preview / what you'll get */}
      <div style={{
        background: 'radial-gradient(ellipse at 60% 40%, #181612 0%, #0e0e0d 60%)',
        borderLeft: '1px solid ' + IC.line,
        padding: '64px 64px',
        display: 'flex', flexDirection: 'column', justifyContent: 'center',
        gap: 32, overflow: 'hidden', position: 'relative',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage:
            'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.04) 1px, transparent 0)',
          backgroundSize: '24px 24px',
          opacity: 0.6,
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'relative', display: 'flex', flexDirection: 'column', gap: 22,
          maxWidth: 460,
        }}>
          <div style={{
            fontSize: 10.5, letterSpacing: '0.18em', textTransform: 'uppercase',
            color: IC.textDim, fontFamily: 'JetBrains Mono, monospace',
          }}>What you'll see</div>

          {/* mini board */}
          <div style={{
            display: 'flex', alignItems: 'flex-start', gap: 22,
          }}>
            <IBoard
              fen="r1bqk2r/pppp1ppp/2n2n2/2b1p2Q/2B1P3/5N2/PPPP1PPP/RNB1K2R"
              size={240}
              highlights={{ c4: 'you', h5: 'them', f3: 'idea' }}
              arrows={[
                { from: 'f6', to: 'h5', kind: 'them' },
              ]}
              showCoords={false}
            />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 6 }}>
              <PreviewMini kind="you" label="You" san="Bc4" />
              <PreviewMini kind="them" label="Them" san="Nxh5" />
              <PreviewMini kind="idea" label="Idea" san="Nf3" />
            </div>
          </div>

          <div style={{
            fontSize: 17, color: IC.text, letterSpacing: '-0.012em',
            lineHeight: 1.4,
            paddingTop: 18, borderTop: '1px solid ' + IC.line,
            maxWidth: 380,
          }}>
            Your move map, your patterns. Every spot comes from
            <span style={{
              fontFamily: '"Instrument Serif", serif', fontStyle: 'italic',
            }}> your </span>
            games — not a puzzle library.
          </div>

          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 0, paddingTop: 12,
          }}>
            <Stat label="Patterns" value="9" />
            <Stat label="Openings" value="13" divider />
            <Stat label="Motifs" value="20+" divider />
          </div>
        </div>
      </div>
    </div>
  );
}

function FormRow({ label, children, mono }) {
  return (
    <div style={{
      padding: '12px 14px',
      borderRadius: 8,
      border: '1px solid ' + IC.line,
      background: IC.surface,
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{
        fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase',
        color: IC.textDim, fontFamily: 'JetBrains Mono, monospace',
      }}>{label}</div>
      <div>{children}</div>
    </div>
  );
}

function PreviewMini({ kind, label, san }) {
  const color = kind === 'you' ? IC.you : kind === 'them' ? IC.them : IC.idea;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{
        width: 6, height: 6, borderRadius: '50%', background: color,
        boxShadow: '0 0 6px ' + color,
      }} />
      <span style={{
        fontSize: 10.5, color: IC.textDim, width: 40,
        fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.1em',
        textTransform: 'uppercase',
      }}>{label}</span>
      <span style={{
        fontSize: 15, color: IC.text,
        fontFamily: 'JetBrains Mono, monospace',
      }}>{san}</span>
    </div>
  );
}

function Stat({ label, value, divider }) {
  return (
    <div style={{
      paddingLeft: divider ? 16 : 0,
      borderLeft: divider ? '1px solid ' + IC.line : 'none',
    }}>
      <div style={{
        fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase',
        color: IC.textDim, fontFamily: 'JetBrains Mono, monospace',
      }}>{label}</div>
      <div style={{
        fontSize: 24, color: IC.text, marginTop: 6, letterSpacing: '-0.02em',
        fontWeight: 300,
      }}>{value}</div>
    </div>
  );
}

window.ImportScreen = ImportScreen;

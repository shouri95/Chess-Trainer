# Pattern Coach Design Specification

## Product Thesis

Pattern Coach is not a chess report app. It is a training surface for future vision.

The product should help a player build the habit every improving chess player needs:

> Before I move, what is my opponent's most forcing reply?

The moat is not that the app finds mistakes. Many products can do that. The moat is that Pattern Coach remembers the exact shapes the user keeps misunderstanding, then turns those shapes into visual practice from the user's own games.

The app should feel like a calm, modern chess tool. It should not feel like a stats dashboard, puzzle website, coaching blog, or generic AI chat wrapper.

## North Star

Pattern Coach should answer one question:

> What reply am I failing to see, and can I train that exact habit until it becomes automatic?

Every screen should support this loop:

```mermaid
flowchart LR
  Game["Real game"] --> Mistake["Critical move"]
  Mistake --> Reply["Opponent reply"]
  Reply --> Pattern["Repeated blindspot"]
  Pattern --> Map["Visual move map"]
  Map --> Drill["Recall practice"]
  Drill --> Memory["Pattern memory"]
  Memory --> Dashboard["Next target"]
```

## Product Principles

### 1. Visual First, Text Last

The board, arrows, highlights, move map, and replay controls should carry the meaning. Text should clarify, not dominate.

Bad:

- long coach paragraphs
- visible engine PV dumps
- multiple advice cards
- generic training plans
- every metric shown at once

Good:

- one visual weakness
- one board
- one move map
- one short insight line
- progressive detail only when requested

### 2. The Engine Is Evidence, Not The Product

Stockfish should support the experience. It should not own the experience.

The user does not need to see raw engine lines by default. The user needs to understand:

- what they played
- what the opponent could do next
- what the safer or stronger idea changes
- whether this is a repeated personal pattern

Raw engine output belongs behind an "Engine lines" drawer.

### 3. Opening Learning Means Purpose, Not Memorization

Opening training must explain why a move belongs in the position.

For an opening move, the app should classify purpose:

- develops a piece
- contests the center
- protects a key pawn
- prepares castling
- prevents a known reply
- enables a pawn break
- avoids a trap

The opening layer should protect known theory from false engine-based criticism. Sharp theory should not be treated as a mistake simply because it allows forcing replies.

### 4. Personal Pattern Memory Is The Moat

The app should stop saying only:

> Opponent replies ignored: 100

It should say, visually and compactly:

> You often move before seeing the forcing reply.

The count is supporting evidence. The product insight is the repeated thinking failure.

### 5. Progressive Disclosure

Default surface:

- board
- move map
- status
- one action

Secondary surface:

- exact line
- engine alternatives
- opening/theory note
- historical examples

Never show all of this at once.

## Core User Loop

1. User imports Chess.com games or PGN.
2. App identifies trainable moves.
3. App clusters them into recurring thinking patterns.
4. Dashboard shows one main weakness.
5. User taps Train or Review.
6. User sees a board and makes a move.
7. App shows a compact move map:

```text
You -> Them -> Idea
```

8. User practices until the reply-recognition habit improves.

## Information Architecture

Primary tabs:

- Dashboard
- Games
- Mistake Lab
- Drill Mode

Optional future mode:

- Analysis Board as a first-class tab, once it supports real move exploration well enough.

Each tab has one job:

- Dashboard: choose today's weakness.
- Games: replay imported games.
- Mistake Lab: understand exact mistakes.
- Drill Mode: build recall.
- Analysis Board: explore a position.

## Dashboard

### Job

The dashboard is not a report. It is a visual command surface.

It should answer:

- What is my main weakness right now?
- What thinking habit do I need to train?
- What is the next action?

### Required Layout

The first viewport should contain one primary surface:

- label: Main weakness
- trend badge
- visual orbit or flow showing `You -> Them -> Idea`
- weakness name
- one short future-vision cue
- 2-3 compact metrics
- top example moves
- Train and Review actions

### Current Preferred Dashboard Model

```text
Main weakness                         Stable

           [You: move]

      Opponent replies ignored
      Train the reply before the move

                     [Them: reply]

          [Idea]

Spots     Review     Clean
1         4m         33%

[Blunder Bc4]

[Train] [Review]
```

### Dashboard Rules

- Show one weakness, not many cards.
- Do not show skill profile by default.
- Do not show move quality distribution by default.
- Do not show recent games by default unless the dashboard becomes scrollable and the first viewport remains clean.
- Avoid "estimated rating" as a hero metric. It is too noisy and can undermine trust.
- Use motion or subtle visual geometry only if it helps show the thinking loop.

### Dashboard Metrics

Use only metrics that help action:

- Spots: number of relevant examples due now.
- Review: estimated minutes.
- Clean: percentage of reviewed moves that were good/best.

Avoid:

- total games
- raw pattern counts
- too many percentages
- rating as a headline
- generic "critical" totals without context

## Move Map

### Job

The Move Map teaches the player to see the consequence sequence.

It replaces long coach text.

### Default Shape

```text
Move map

You        ->        Them        ->        Idea
Bc4                  Nxh5                  Qxe5+

After Bc4, Black has Nxh5, capturing the queen on h5.
```

### Compact Shape Before A Move

```text
Move map

You        ->        Them
candidate            reply

Before you move, predict their most forcing reply.
```

### Rules

- The map should fit in a compact card below or beside the board.
- It should never become a paragraph-heavy coach note.
- It should show at most three nodes.
- It should show one insight line.
- It should use SAN when possible, UCI only as fallback.
- It should avoid overclaiming. Prefer "Idea" over "Best" when the engine is shallow or uncertain.

### Node Semantics

You:

- the move the user played or is considering

Them:

- the opponent's most forcing or engine-backed reply

Idea:

- the engine idea, opening-book move, or safer candidate

### Visual Semantics

Use consistent color language:

- You: warm amber
- Them: red or coral
- Idea: green
- Neutral/unknown: muted gray

Arrows on the board should match these colors.

## Learn Mode

### Job

Learn Mode makes thinking visible without turning the app into an article.

### Behavior

When off:

- user sees board, status, controls
- engine lines are hidden
- no explanatory clutter

When on:

- board highlights the user's move, opponent reply, and suggested idea
- Move Map appears
- one insight line appears

### Toggle Design

The toggle should be small and tool-like.

Good labels:

- Move map On/Off
- Learn On/Off

Avoid:

- long explanatory labels
- large in-app tutorial copy
- modal walkthroughs

### Learn Mode By Screen

Dashboard:

- always visual, not toggle-based

Mistake Lab:

- Learn Mode defaults on for mistake details
- user can turn it off

Drill Mode:

- Learn Mode defaults off
- user can enable it when stuck or reviewing

Analysis Board:

- Learn Mode defaults off
- user can enable it while exploring

## Mistake Lab

### Job

Mistake Lab helps the user understand exact positions from their games.

It should not feel like a spreadsheet of errors.

### List View

List items should be compact:

- phase
- SAN
- quality
- pattern title
- one consequence phrase

Do not show long explanations in list items.

### Detail View

The detail view should be board-first.

Required elements:

- large board
- segmented control: Your move / Idea / Consequence
- move map
- Train action
- previous/next controls

Optional collapsed elements:

- engine lines
- full game context
- opening name

### Detail View Rule

If the user opens a mistake, the first thing they should see is the position and the move relationship, not a paragraph.

## Drill Mode

### Job

Drill Mode builds recall.

The user should feel like they are playing a real position, not answering a quiz.

### Default State

Show:

- board
- side to move
- opening or phase
- progress strip
- controls
- optional Move Map toggle

Do not show:

- best move
- raw engine line
- long explanation
- full mistake story before attempt

### After A Move

Correct:

- mark solved
- show move map if Learn Mode is on
- allow next

Wrong:

- show the concrete reply or target
- reset unless Learn Mode is on and the visual consequence is useful
- avoid humiliating copy

### Drill States

- Idle: waiting for the user to move.
- Thinking: checking move.
- Correct: move solves the position.
- Theory: move is accepted opening theory.
- Wrong: move fails tactically or strategically.
- Review: user is looking at the consequence.

### Drill Controls

Required:

- previous
- reset
- hint
- next

Optional:

- filter drawer
- category selector
- engine drawer

## Analysis Board

### Job

The Analysis Board is for exploration, not training.

It should answer:

- what happens if I play this?
- what reply should I expect?
- how does the evaluation change?

### Default Surface

- board
- eval bar
- compact controls
- move log
- Learn Mode toggle
- engine lines hidden in drawer

### Engine Lines

Engine lines should be collapsed by default.

Users who want raw engine output can open it. Beginners should not be forced to parse it.

## Games

### Job

Games lets the user replay and navigate imported games.

The games screen should not compete with Mistake Lab.

Default state:

- game list
- opponent
- result
- time control
- opening when available

Game detail:

- board replay
- move strip
- optional report panel
- double-tap or action to open mistake details

## Import And Profile

### Job

Import should feel practical and trustworthy.

Primary controls:

- Chess.com username
- connect/sync
- month range
- game cap
- PGN paste/upload
- sample data

Rules:

- Time-control filtering belongs in Games and Mistake Lab after import.
- Do not show a marketing landing page.
- The first-run screen can be simple, but should still feel like a real tool.

## Chess Intelligence Architecture

### Analysis Layers

```mermaid
flowchart TD
  PGN["PGN / Chess.com games"] --> Normalize["Normalize games and moves"]
  Normalize --> Engine["Engine review"]
  Normalize --> Opening["Opening book"]
  Engine --> Quality["Move quality"]
  Opening --> Quality
  Quality --> Patterns["Pattern detectors"]
  Patterns --> Families["Position families"]
  Families --> Memory["Pattern memory"]
  Memory --> Dashboard["Main weakness"]
  Patterns --> MoveMap["Move map evidence"]
```

### Move Review Contract

Each reviewed move should eventually have:

- fenBefore
- fenAfter
- SAN
- UCI
- player color
- phase
- opening
- quality
- engine best move
- opponent reply after played move
- motif
- confidence
- evidence

### Explanation Contract

Explanations must be structured data first, UI copy second.

Preferred contract:

```ts
type MoveMap = {
  played?: string;
  reply?: string;
  idea?: string;
  motif: string;
  insight: string;
  confidence: "low" | "medium" | "high";
  highlights: Record<Square, HighlightRole>;
  arrows: Arrow[];
};
```

The app should never depend on raw free-form text as the only source of truth.

## Engine Discipline

### Problem

Shallow engine suggestions can be unhelpful, especially in openings and tactical positions.

### Rules

1. Never call an engine move "best" unless confidence is high enough.
2. Use "Idea" when depth is low, timed out, or book context is missing.
3. In openings, check book/theory before judging.
4. Use MultiPV to compare alternatives.
5. Separate tactical refutations from small engine preferences.
6. Hide raw engine output by default.
7. Surface confidence subtly when needed.

### Judgement Order

1. Is the move legal?
2. Is the position known opening theory?
3. Does the move satisfy the opening plan?
4. Does the move solve the original pattern?
5. What is the opponent's forcing reply?
6. What does the engine prefer?
7. Is the difference meaningful or just engine taste?

## Opening Knowledge

### Goal

Opening intelligence should teach purpose.

Initial repertoire coverage:

- Italian Game
- Two Knights Defense
- Fried Liver Attack
- Giuoco Piano
- Ruy Lopez
- Scotch Game
- Queen's Gambit
- London System
- Sicilian Defense
- French Defense
- Caro-Kann
- King's Indian structures
- common beginner traps and anti-traps

### Opening Move Purpose Categories

- Develops a piece
- Attacks/protects center
- Prepares castling
- Prevents a tactic
- Supports a pawn break
- Creates a threat
- Avoids a known trap
- Improves king safety

### Opening UX

Instead of:

> The engine prefers Nf3.

Prefer:

```text
Nf3
Develops and protects e5/e4 squares.
```

Or in Move Map form:

```text
You -> Them -> Idea
Qh5    Nxh5    Nf3
```

## Pattern Intelligence

### Current Pattern Families

- Loose pieces
- Missed forcing moves
- Opponent replies ignored
- King shelter weakened
- King in center too long
- Opening tempo leaking
- Queen out too early
- Passive endgame king
- Not simplifying wins

### Desired Pattern Output

Raw:

```text
Opponent replies ignored: 100
```

Productized:

```text
Main weakness
You often move before seeing the reply.
```

Visual:

```text
You -> Them -> Idea
move   reply   safer plan
```

### Pattern Ranking

Rank patterns by:

- severity
- frequency
- recency
- repeated position family
- trend direction
- drill failure rate
- relapse after previous success

Do not rank only by count.

## Visual Design Direction

### Tone

- modern
- quiet
- premium
- board-first
- tool-like
- chess-native

### Avoid

- marketing-style hero sections
- generic cards everywhere
- text-heavy dashboards
- one-note color palettes
- decorative gradients with no purpose
- oversized motivational copy
- raw PV text as primary UI
- cartoonish coaching language

### Prefer

- dense but calm surfaces
- restrained color
- clear board hierarchy
- compact metadata
- direct controls
- progressive drawers
- move maps
- visual reply paths

### Cards

Use cards sparingly:

- dashboard hero surface
- repeated list items
- modal/bottom-sheet containers
- compact tool panels

Do not nest cards inside cards.

## Board Design

### Requirements

- high contrast pieces
- subtle coordinates
- stable square sizing
- legal move dots
- capture indicators
- last move highlight
- optional arrows
- responsive sizing
- no layout shift from status text

### Highlight Roles

- played move: amber
- opponent reply: red
- suggested idea: green
- target square: red fill
- safe square: green fill
- selected piece: neutral/blue

### Arrow Rules

- Do not show more than three arrows at once.
- Do not show engine arrows by default in Drill Mode before the user moves.
- Keep arrow opacity moderate.
- Use consistent color semantics across screens.

## Copy Rules

### Voice

Short, precise, chess-specific.

Good:

- "Predict the reply."
- "Nxh5 wins the queen."
- "Castle before the center opens."
- "Develop before moving the queen again."

Bad:

- "This is an instructive position where you should think more carefully."
- "The engine has identified a weakness in your strategic decision-making."
- "You need to improve your tactical awareness."

### Length Limits

Dashboard:

- one short cue, under 16 words when possible

Move Map insight:

- one sentence

Mistake list:

- one phrase

Engine drawer:

- raw notation is allowed

## Data Persistence

The app should persist:

- imported games
- normalized move records
- engine evaluations
- pattern summaries
- position family fingerprints
- drill outcomes
- Learn Mode preference
- pattern history snapshots

Future persistence should move toward IndexedDB or SQLite for larger game sets.

## Testing Expectations

Unit tests:

- move-map generation
- engine score normalization
- move quality classification
- opening book protection
- pattern clustering
- drill judgement

UI verification:

- dashboard first viewport has one main weakness
- drill screen does not reveal answer before attempt
- Learn Mode toggle works
- engine lines are hidden by default
- text fits on mobile
- board remains usable at mobile widths

Browser QA should include:

- first-run sample load
- dashboard visual surface
- Mistake Lab detail
- Drill Mode with Learn Mode off and on
- Analysis Board engine drawer

## Roadmap

### Phase 1: Clean Visual Foundation

- One-main-weakness dashboard.
- Compact Move Map.
- Engine lines hidden by default.
- Learn Mode progressive disclosure.

### Phase 2: Better Chess Semantics

- Motif detection for pins, forks, skewers, overloaded defenders, trapped pieces.
- Opening purpose graph for common openings.
- Position family clustering with stronger board features.

### Phase 3: Training Memory

- Track solved, failed, hinted, skipped.
- Schedule reviews with spaced repetition.
- Detect relapse in future games.

### Phase 4: Similar Position Generation

- Train from user's games first.
- Add similar curated or generated positions later.
- Keep the motif and move-map structure consistent.

### Phase 5: Advanced Explanation

- Optional AI wording from structured evidence.
- Never let model prose invent chess facts.
- Always ground explanations in legal moves, engine lines, opening book, or detected motifs.

## Product Red Lines

Do not:

- make the dashboard a text report
- make the engine line the main teacher
- call uncertain engine output "best"
- show long coach explanations by default
- make drills passive
- train generic puzzles before personal mistakes
- add decorative UI that competes with the board

Do:

- make the user see the opponent's reply
- make practice feel like real chess
- keep the board central
- use text only when it sharpens the visual
- make every screen answer one question

## Final Standard

A good Pattern Coach screen should make the user think:

> I see the move. I see the reply. I understand what I was missing.

If the screen instead makes the user read, compare statistics, or parse engine notation before seeing the chess idea, the design is failing.
